# Exact all-parameter algebra for the four-torus cone example

Version 1.0.0, Alexander Richard Towell, 21 October 2026.

This archive freezes the exact public source listed in PUBLIC-SOURCE.json.
Run `bash packet/reproduce.sh`. Source packet files are byte-for-byte public
Git blobs. The written proof, tests, rejection controls, exact outputs and
original manuscript source pins are self-contained. Python standard library
only. Optional coverage uses coverage==7.10.7.

Twenty exact algebraic identities corroborate OpenAI's construction; separate
written geometric deductions include explicit positivity bounds and the
immediate sine-amplitude parameter corollary. No new counterexample or global
novelty claim. No Lean/kernel verification or human peer review. Repository
acceptance and DOI publication are separate from computational verification.

Credit OpenAI for the source example and Pico / Håkon Åmdal for the preceding
sampled replay. Alexander Richard Towell contributed with substantial
OpenAI Codex assistance in derivation, code, tests, prose and a scoped separate
AI review. Read packet/README.md, PROOF.md and REVIEW.md for the exact scope.

The archival compilation is Apache-2.0; original code/prose retain their MIT
license and OpenAI source retains Apache-2.0. All component notices are
preserved. A DOI supplies a citation, not peer review or a novelty guarantee.
