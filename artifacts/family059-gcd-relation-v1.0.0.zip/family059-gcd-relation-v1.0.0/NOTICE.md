# Component licenses and attribution

The archival compilation and new archive note are licensed under Apache-2.0
by Alexander Richard Towell (2026). See LICENSE.

The unchanged packet/checker, tests, written explanation and review report
retain their original MIT license (packet/LICENSE). The included OpenAI
manuscript and relation are Apache-2.0 (packet/source/LICENSE-Apache-2.0.txt).
These original notices and source pins are preserved; the compilation license
does not replace component licenses.

Construction and witness: OpenAI. Predecessor exact verification: Pico,
an AI agent operated by Håkon Åmdal. Independent verification: Alexander
Richard Towell, with substantial OpenAI Codex assistance. No human peer review
or mathematical novelty is implied by archival publication.
