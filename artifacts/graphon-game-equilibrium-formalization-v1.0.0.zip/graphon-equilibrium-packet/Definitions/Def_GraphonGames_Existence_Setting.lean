import Mathlib

namespace GraphonGames.Existence

open MeasureTheory
open scoped ENNReal

/-- The player space `I = [0, 1]`, with Lebesgue measure `volume` (a probability measure). -/
abbrev I : Type := unitInterval

/-- A graphon (p. 8): a symmetric, `𝓑(I) × 𝓑(I)`-measurable, real-valued, square-integrable
function on `I × I`. -/
def IsGraphon (w : I → I → ℝ) : Prop :=
  Measurable (Function.uncurry w) ∧ (∀ x y, w x y = w y x) ∧
    MemLp (Function.uncurry w) 2 (volume : Measure (I × I))

/-- The graphon operator (p. 8): `[W g]_x = ∫_I w(x, y) g(y) dy`. -/
noncomputable def graphonApply (w : I → I → ℝ) (g : I → ℝ) : I → ℝ :=
  fun x => ∫ y, w x y * g y

/-- The operator norm `‖W‖ = sup_{φ ∈ L²(I), ‖φ‖_{L²} = 1} ‖W φ‖_{L²}` (p. 8), in `ℝ≥0∞`. -/
noncomputable def opNorm (w : I → I → ℝ) : ℝ≥0∞ :=
  ⨆ (φ : I → ℝ) (_ : MemLp φ 2 volume ∧ eLpNorm φ 2 volume = 1),
    eLpNorm (graphonApply w φ) 2 volume

/-- Assumption 1 (p. 3), with the standing mean-zero noise (pp. 3, 7). -/
def Asm1 (b : ℝ → ℝ → ℝ) (μ0 : Measure ℝ) (cα cz : ℝ) : Prop :=
  0 ≤ cα ∧ 0 ≤ cz ∧
    (∀ a z a' z', (b a z - b a' z') ^ 2 ≤ cα * (a - a') ^ 2 + cz * (z - z') ^ 2) ∧
    IsProbabilityMeasure μ0 ∧ Integrable (fun ξ => ξ ^ 2) μ0 ∧ ∫ ξ, ξ ∂μ0 = 0

/-- The cost `J(α, z) = E[f(X_{α,z,ξ}, α, z)]` with `X = b(α, z) + ξ`, `ξ ∼ μ₀` ((1), p. 3; p. 10). -/
noncomputable def cost (b : ℝ → ℝ → ℝ) (f : ℝ → ℝ → ℝ → ℝ) (μ0 : Measure ℝ) (a z : ℝ) : ℝ :=
  ∫ ξ, f (b a z + ξ) a z ∂μ0

/-- Assumption 4 (pp. 10–11) on `J : A × ℝ → ℝ` (first argument the action). -/
def Asm4 (J : ℝ → ℝ → ℝ) (ℓc ℓJ : ℝ) : Prop :=
  0 < ℓc ∧ 0 ≤ ℓJ ∧ (∀ z, ContDiff ℝ 1 (fun a => J a z)) ∧
    (∀ a a' z ε, 0 ≤ ε → ε ≤ 1 →
      J (ε * a + (1 - ε) * a') z ≤
        ε * J a z + (1 - ε) * J a' z - ℓc / 2 * ε * (1 - ε) * |a - a'| ^ 2) ∧
    (∀ a z z', |deriv (fun a => J a z') a - deriv (fun a => J a z) a| ≤ ℓJ * |z' - z|)

/-- Assumption 5 (p. 15): `|b(α, z)| ≤ c₀` for a finite positive constant `c₀`. -/
def Asm5 (b : ℝ → ℝ → ℝ) (c0 : ℝ) : Prop :=
  0 < c0 ∧ ∀ a z, |b a z| ≤ c0

/-- `z` is an aggregate of the profile `α` ((6), Proposition 3.1, p. 8):
`z ∈ L²(I)` and `z_x = ∫_I w(x, y) b(α_y, z_y) dy` for a.e. `x`. -/
def IsAggregate (w : I → I → ℝ) (b : ℝ → ℝ → ℝ) (α z : I → ℝ) : Prop :=
  MemLp z 2 volume ∧ ∀ᵐ x ∂volume, z x = ∫ y, w x y * b (α y) (z y)

/-- The best response `B z` (p. 11): for each player, a minimizer of `a ↦ J(a, z_x)`. -/
noncomputable def bestResponse (J : ℝ → ℝ → ℝ) (z : I → ℝ) : I → ℝ :=
  fun x => Classical.epsilon (fun a => ∀ β, J a (z x) ≤ J β (z x))

/-- Nash equilibrium of the graphon game, in the form of the third bullet of Proposition 3.6 (p. 11):
an `L²` profile `α` with an aggregate `z = Zα` such that for a.e. `x` and every action `β`,
`J(α_x, z_x) ≤ J(β, z_x)`. -/
def IsNash (w : I → I → ℝ) (b : ℝ → ℝ → ℝ) (f : ℝ → ℝ → ℝ → ℝ) (μ0 : Measure ℝ) (α : I → ℝ) :
    Prop :=
  MemLp α 2 volume ∧ ∃ z, IsAggregate w b α z ∧
    ∀ᵐ x ∂volume, ∀ β : ℝ, cost b f μ0 (α x) (z x) ≤ cost b f μ0 β (z x)

end GraphonGames.Existence
