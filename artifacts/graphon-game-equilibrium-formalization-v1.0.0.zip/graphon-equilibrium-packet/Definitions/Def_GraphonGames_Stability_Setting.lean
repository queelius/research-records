import Mathlib
import Definitions.Def_GraphonGames_Existence_Setting

open MeasureTheory
open scoped ENNReal

namespace GraphonGames.Stability

abbrev I := unitInterval

/-- Real-valued symmetric square-integrable graphons on the player interval. -/
def IsGraphon (w : I → I → ℝ) : Prop :=
  Measurable (Function.uncurry w) ∧
  (∀ x y, w x y = w y x) ∧
  MemLp (Function.uncurry w) 2 (volume : Measure (I × I))

/-- The integral operator associated with a graphon kernel. -/
noncomputable def graphonApply (w : I → I → ℝ) (g : I → ℝ) : I → ℝ :=
  fun x => ∫ y, w x y * g y

/-- The L²-to-L² operator norm, taken in the extended nonnegative reals. -/
noncomputable def opNorm (w : I → I → ℝ) : ℝ≥0∞ :=
  ⨆ (φ : I → ℝ) (_ : MemLp φ 2 volume ∧ eLpNorm φ 2 volume = 1),
    eLpNorm (graphonApply w φ) 2 volume

/-- Equation (6), with profiles represented by functions modulo a.e. equality. -/
def IsAggregate (w : I → I → ℝ) (b : ℝ → ℝ → ℝ)
    (α z : I → ℝ) : Prop :=
  MemLp z 2 volume ∧
  ∀ᵐ x ∂volume, z x = ∫ y, w x y * b (α y) (z y)

/-- The unique pointwise minimizer selected using classical choice. -/
noncomputable def bestResponse (J : ℝ → ℝ → ℝ) (z : I → ℝ) : I → ℝ :=
  fun x => Classical.epsilon (fun a => ∀ β, J a (z x) ≤ J β (z x))

/-- Nash equilibrium in the equivalent form of Proposition 3.6. -/
def IsNash (w : I → I → ℝ) (b : ℝ → ℝ → ℝ)
    (f : ℝ → ℝ → ℝ → ℝ) (μ0 : Measure ℝ) (α : I → ℝ) : Prop :=
  MemLp α 2 volume ∧
  ∃ z, IsAggregate w b α z ∧
    ∀ᵐ x ∂volume, ∀ β : ℝ, GraphonGames.Existence.cost b f μ0 (α x) (z x) ≤ GraphonGames.Existence.cost b f μ0 β (z x)

end GraphonGames.Stability
