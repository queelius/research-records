import Mathlib
import Definitions.Def_GraphonGames_Stability_Setting

open MeasureTheory
open scoped ENNReal
set_option autoImplicit false
theorem solution : True := by trivial

namespace GraphonGames.Stability

theorem exact_target
    (J : ℝ → ℝ → ℝ) (ℓc ℓJ : ℝ) (h4 : GraphonGames.Existence.Asm4 J ℓc ℓJ)
    (z1 z2 : I → ℝ) (hz1 : MemLp z1 2 volume)
    (hz2 : MemLp z2 2 volume) :
    eLpNorm (bestResponse J z1 - bestResponse J z2) 2 volume ≤
      ENNReal.ofReal (ℓJ / ℓc) * eLpNorm (z1 - z2) 2 volume := by
  exact solution J ℓc ℓJ h4 z1 z2 hz1 hz2

end GraphonGames.Stability

#print axioms GraphonGames.Stability.exact_target


-- Generated proof_workflow guard; keep the independent audit above.
run_cmd do
  let env ← Lean.getEnv
  let some info := env.find? `solution | throwError "Missing top-level solution"
  unless info.isTheorem do throwError "solution must be a theorem"
  if env.isImportedConst `solution then throwError "solution must be local"
  let forbidden : String := "Theorems.Thm_GraphonGames_Stability_lemma_3_7_best_response_lipschitz"
  for moduleName in env.header.moduleNames do
    if moduleName.toString == forbidden then throwError "Circular target import"
  let allowed : Array Lean.Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let localDecls := env.constants.foldStage2 (fun xs n c => xs.push (n, c)) #[]
  for (name, decl) in localDecls do
    if !env.isImportedConst name then
      if decl.isAxiom then throwError "Local axiom is forbidden: {name}"
      for axiomName in (← Lean.collectAxioms name) do
        unless allowed.contains axiomName do
          throwError "Unexpected axiom in local declaration: {axiomName}"
  let axioms ← Lean.collectAxioms `solution
  for axiomName in axioms do
    unless allowed.contains axiomName do
      throwError "Unexpected axiom in solution: {axiomName}"
  let data := Lean.Json.arr (axioms.map fun n => Lean.Json.str n.toString)
  IO.println ("PROOF_WORKFLOW_AXIOMS f0ebc82204a44a9698c7d075da29dfa7 " ++ data.compress)
