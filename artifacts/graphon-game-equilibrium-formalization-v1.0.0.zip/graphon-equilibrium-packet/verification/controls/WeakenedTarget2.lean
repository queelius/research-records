import Mathlib
import Definitions.Def_GraphonGames_Stability_Setting

open MeasureTheory
open scoped ENNReal
set_option autoImplicit false
theorem solution : True := by trivial

namespace GraphonGames.Stability

theorem exact_target
    (b : ℝ → ℝ → ℝ) (μ0 : Measure ℝ) (cα cz : ℝ)
    (h1 : GraphonGames.Existence.Asm1 b μ0 cα cz)
    (w : I → I → ℝ) (hw : IsGraphon w)
    (hW : Real.sqrt cz * (opNorm w).toReal < 1)
    (α1 α2 : I → ℝ) (hα1 : MemLp α1 2 volume)
    (hα2 : MemLp α2 2 volume)
    (z1 z2 : I → ℝ) (hz1 : IsAggregate w b α1 z1)
    (hz2 : IsAggregate w b α2 z2) :
    eLpNorm (z1 - z2) 2 volume ≤
      ENNReal.ofReal
        (Real.sqrt cα * (opNorm w).toReal /
          (1 - Real.sqrt cz * (opNorm w).toReal)) *
        eLpNorm (α1 - α2) 2 volume := by
  exact solution b μ0 cα cz h1 w hw hW α1 α2 hα1 hα2 z1 z2 hz1 hz2

end GraphonGames.Stability
#print axioms GraphonGames.Stability.exact_target


-- Generated proof_workflow guard; keep the independent audit above.
run_cmd do
  let env ← Lean.getEnv
  let some info := env.find? `solution | throwError "Missing top-level solution"
  unless info.isTheorem do throwError "solution must be a theorem"
  if env.isImportedConst `solution then throwError "solution must be local"
  let forbidden : String := "Theorems.Thm_GraphonGames_Stability_lemma_3_16_aggregate_lipschitz"
  for moduleName in env.header.moduleNames do
    if moduleName.toString == forbidden then throwError "Circular target import"
  let allowed : Array Lean.Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let localDecls := env.constants.foldStage2 (fun xs n c => xs.push (n, c)) #[]
  for (name, decl) in localDecls do
    if !env.isImportedConst name then
      if decl.isAxiom then throwError "Local axiom is forbidden: {name}"
      for axiomName in (← Lean.collectAxioms name) do
        unless allowed.contains axiomName do
          throwError "Unexpected axiom in local declaration: {axiomName}"
  let axioms ← Lean.collectAxioms `solution
  for axiomName in axioms do
    unless allowed.contains axiomName do
      throwError "Unexpected axiom in solution: {axiomName}"
  let data := Lean.Json.arr (axioms.map fun n => Lean.Json.str n.toString)
  IO.println ("PROOF_WORKFLOW_AXIOMS 2a324cd782fb469b8d93a74e5621b41a " ++ data.compress)
