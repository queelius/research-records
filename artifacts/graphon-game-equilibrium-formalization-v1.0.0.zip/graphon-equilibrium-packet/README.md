# Graphon aggregates, equilibria and fixed-profile perturbations

Version 1.0.0 · [10.5281/zenodo.23534943](https://doi.org/10.5281/zenodo.23534943). Identifiers were reserved during assembly; the separate publication receipt establishes public availability. NOTE.md states all five complete results, exact assumptions,
proof ideas, source correspondence, attribution and limits. The original
mathematics is due to Carmona, Cooney, Graves and Laurière, with inherited
credit to Parise and Ozdaglar for the best-response predecessor estimate.

## Reproduce

From this directory on Linux/POSIX with Python 3.10+, Git and elan:

```sh
python3 scripts/verify_archive.py --integrity-only
python3 scripts/verify_archive.py --setup
```

First setup needs network and several GB of disk, without platform credentials.
Expected: five compiled complete-target audits, two freshly compiled platform
definitions, autoImplicit=false and only propext, Classical.choice and Quot.sound.
Verified pinned third-party caches are trusted inputs. See verification/README.md.

## Evidence and scope

Accepted proof/audit bytes are unchanged. All required platform sources,
receipt hashes, independent exact types and licenses are included. Historical
filesystem prefixes are normalized with original hashes retained. Target JSON
contains by-sorry placeholders only as original statement text, not proofs.
Invalid controls test all five target interfaces, a forbidden unused local
axiom and changed proof bytes; all must reject and were never submitted.

MANIFEST.json inventories every packet file except itself. This edition adds
no platform target. It proves the exact real-action, almost-everywhere model;
it does not prove the source's Fubini-extension equivalence, general constrained
actions, equilibrium perturbation Theorem 3.20 or finite-player approximation.
The fixed-profile perturbation bound does not establish equilibrium sensitivity.
No mathematical novelty, source-author endorsement or human peer review is claimed.
