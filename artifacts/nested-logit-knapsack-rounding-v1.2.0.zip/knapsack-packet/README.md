# Uniform candidate families and knapsack rounding

Version 1.2.0 · reserved exact-version DOI
[10.5281/zenodo.23529835](https://doi.org/10.5281/zenodo.23529835).
The later central publication receipt establishes public availability.

This packet contains four complete accepted Lean proofs of established
Gallego–Topaloglu mathematics: a uniform feasible family of at most `(n+1)^2`
assortments with a factor-two guarantee for every nonnegative parameter,
actual fractional-knapsack optimizer construction, factor-two rounding and
the separate refined small-item utility bound. See NOTE.md for the argument,
record.json for exact targets and credit, and provenance.json for source pins.
The global multi-nest revenue algorithm, running-time bound and refined uniform
small-item guarantee remain separate claims. Version 1.1.0 is preserved in the
same DOI family; its published three-proof archive remains independently citable.

## Reproduce

On Linux/POSIX, use Python 3.10+, Git and the elan Lean toolchain manager.
From the extracted packet root:

```sh
python3 scripts/verify_archive.py --integrity-only
python3 scripts/verify_archive.py --setup
```

The first command checks hashes, receipts and dependency pins without Lean
or a network. The second obtains Lean 4.33.1 and immutable Mathlib/transitive
dependency revisions, downloads compiled caches, freshly builds all three
platform modules, and checks all four complete target/axiom audits with
autoImplicit=false. First setup needs network access and several GB of disk.
No Prove2Me account or credentials are required. Subsequent runs can omit
--setup; verification/README.md explains explicit verified-cache reuse.

A successful JSON report has status passed, four targets with compiled true,
and only propext, Classical.choice and Quot.sound as axioms. Third-party
compiled caches are trusted inputs; this is not a bootstrap check of Lean
or Mathlib. The verifier is unchanged from the source commit in provenance.json.

## Evidence and controls

Exact accepted proofs are under contributions/queelius/proofs/. Each audit
in evidence/checks/ includes the accepted proof as an exact byte prefix, a
complete independent target signature and guards against local/unapproved
axioms and circular target imports. Definitions/ contains all platform
dependencies; no open theorem placeholder is imported. The target JSON may
contain the platform's by-sorry statement placeholder as historical text.

verification/receipt.json records the fresh staged-packet reproduction and
intentionally rejected controls. Invalid controls are excluded from accepted
sources and must fail; they were never submitted. Historical command/log
filesystem prefixes are normalized to portable labels, with original and
normalized hashes retained. Proof/audit/definition bytes are unchanged.
MANIFEST.json inventories every packet file except the manifest itself.

## Credit and citation

Cite the exact archival version using CITATION.cff and cite Gallego/Topaloglu
for the underlying mathematics. Alexander Richard Towell directed; OpenAI
Codex substantially formalized, verified and documented; prior platform and
Lean/Mathlib contributors retain credit in NOTICE.md. Formal verification,
platform acceptance, public disclosure, archival publication and human review
are separately dated/qualified. See LICENSE, LICENSE-METADATA and NOTICE.md.
