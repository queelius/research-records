import Mathlib
import Definitions.Def_ConstrNestedLogit_Space_Model

theorem solution : True := by
  trivial

namespace ConstrNestedLogit.Space
example {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (I : NestedLogitVariants.LP.Instance ι n)
    (w : ι → Fin n → ℝ) (c : ι → ℝ) (i : ι)
    (hn : 0 < n)
    (hvnp : ∀ i, I.vnp i = 0) (hv : ∀ j, 0 < I.v i j)
    (hw : ∀ j, 0 < w i j) (hwc : ∀ j, w i j ≤ c i) :
    ∃ A : Finset (Finset (Fin n)),
      isRoundedCandidateFamily I w c i A ∧
      (∀ S ∈ A, spaceFeasible w c i S) ∧
      A.card ≤ (n + 1) ^ 2 ∧
      ∀ u : ℝ, 0 ≤ u → ∃ S ∈ A, isApproximateAt I w c i u 2 S := by
  exact solution I w c i hn hvnp hv hw hwc
end ConstrNestedLogit.Space


-- Generated proof_workflow guard; keep the independent audit above.
run_cmd do
  let env ← Lean.getEnv
  let some info := env.find? `solution | throwError "Missing top-level solution"
  unless info.isTheorem do throwError "solution must be a theorem"
  if env.isImportedConst `solution then throwError "solution must be local"
  let forbidden : String := "Theorems.Thm_ConstrNestedLogit_Space_theorem_6"
  for moduleName in env.header.moduleNames do
    if moduleName.toString == forbidden then throwError "Circular target import"
  let allowed : Array Lean.Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let localDecls := env.constants.foldStage2 (fun xs n c => xs.push (n, c)) #[]
  for (name, decl) in localDecls do
    if !env.isImportedConst name then
      if decl.isAxiom then throwError "Local axiom is forbidden: {name}"
      for axiomName in (← Lean.collectAxioms name) do
        unless allowed.contains axiomName do
          throwError "Unexpected axiom in local declaration: {axiomName}"
  let axioms ← Lean.collectAxioms `solution
  for axiomName in axioms do
    unless allowed.contains axiomName do
      throwError "Unexpected axiom in solution: {axiomName}"
  let data := Lean.Json.arr (axioms.map fun n => Lean.Json.str n.toString)
  IO.println ("PROOF_WORKFLOW_AXIOMS 6a362874da734ecbbff2ec63e8cec27a " ++ data.compress)
