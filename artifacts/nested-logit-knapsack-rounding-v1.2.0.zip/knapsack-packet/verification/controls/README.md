# Intentionally invalid controls

These sources are excluded from accepted proof and dependency manifests.
ExtraAxiomControl retains the complete accepted uniform-family Theorem6 proof
and full independent target audit, but adds an unused False axiom immediately
before the original guard. The guard must reject even an unused local axiom.

WeakenedTargetControl replaces that candidate by a proof of True while keeping
the complete quantified Theorem6 audit. It must fail at the target application.
This checks that a weaker proposition cannot replace the uniform family claim.

The byte-mutation control appends a newline to an accepted proof in an isolated
packet copy and runs the unchanged integrity verifier. It must reject the hash.
No invalid control is submitted. Rejection logs and exit codes are retained.
