# Weighted least-change and DFP proof packet

This version contains two complete accepted Lean formalizations: weighted
Hilbert–Schmidt secant minimization and its DFP specialization. Read NOTE.md
for the claims, assumptions, proof mechanism, source fidelity and credits.
record.json is the structured contribution record; CITATION.cff identifies
the exact archival version. Original source mathematics and reused vebis
formalizations remain separately attributed.

## Contents

- `contributions/queelius/proofs/`: unchanged accepted proof sources.
- `contributions/queelius/evidence/`: complete target audits, logs and receipts.
- `Definitions/`: the three exact platform definition modules.
- `prior-proofs/`: unchanged original vebis PSB and ideal-property proofs.
- `targets/`: exact complete platform statements and preambles.
- `verification/`: pinned environment, source hashes, fresh reproduction,
  invalid controls and verification receipts.
- `scripts/verify_archive.py`: the established, unchanged archive verifier.
- `MANIFEST.json`: SHA-256 and size for every other payload file.

The cited papers and third-party compiled caches are not redistributed.
Private credentials, research queues and unrelated contributions are excluded.
The owning repository remains private; the included sources and explicit
dependency pins make this selected contribution reproducible independently.

## Reproduce the exact targets

From this packet’s root, Python 3.10 or later can check the archive without
credentials or Lean:

```bash
python3 scripts/verify_archive.py --integrity-only
```

To install the pinned dependencies and compile both complete target audits:

```bash
python3 scripts/verify_archive.py --setup
```

This requires network access and disk space for Lean 4.33.1 and the exact
Mathlib revision. The verifier checks dependencies, rebuilds the three platform
modules and checks the complete signatures and axioms. No Prove2Me credential
or access to the private source repository is needed. See verification/README.md
for explicit reuse of compatible third-party compiled caches. The published
checks reuse verified caches; they do not bootstrap-verify Lean or Mathlib.

Expected result: both target audits compile with `autoImplicit=false`, and
their axiom sets are subsets of `propext`, `Classical.choice` and `Quot.sound`.
Actual source hashes, log hashes and exit codes appear in the verification
receipt. Exact source files must not be edited in place.

## Reproduce the rejection controls

`verification/controls/` contains deliberately invalid inputs and their
expected diagnostics. The two added-hypothesis controls retain valid proof
bodies but add a `False` premise to the target interface. The independent
complete-type audits reject them. The unused-axiom control must be rejected
by the local-declaration guard even though the solution does not depend on it.

After a successful verifier run, use its JSON report’s `lean_path` list as
`LEAN_PATH`, and its compiler command, to compile each control with
`-DautoImplicit=false`. Each control must exit nonzero with the diagnostic
recorded in `verification/receipt.json`; unrelated import/setup failures do
not count as successful controls. The report path is printed by the verifier.

The byte-mutation control is independent of Lean: in a separate copy of this
packet, append one newline to either accepted proof and run the integrity-only
command. It must fail with `SHA256 hash mismatch`. Keep the original intact.

## Interpretation and reuse

Two exact target obligations are counted. Bundled predecessor proofs are not
additional contributions by queelius. The DFP factor is supplied explicitly;
factor existence, positivity, BFGS equivalence and algorithm convergence remain
outside these claims. Formal checking and platform acceptance do not establish
mathematical novelty, human peer review or source-author endorsement.

The original public proof submissions, acceptances and later DOI publication
are recorded as separate events. Cite this exact version and the relevant
mathematical sources. Preserve NOTICE.md and the original notices when reusing
the Apache-2.0 material.

Exact-version DOI: [10.5281/zenodo.23541281](https://doi.org/10.5281/zenodo.23541281). Identifiers were reserved during assembly; the separate publication receipt establishes public availability.
