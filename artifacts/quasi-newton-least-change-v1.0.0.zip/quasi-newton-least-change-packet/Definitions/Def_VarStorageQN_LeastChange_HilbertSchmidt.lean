import Mathlib

namespace VarStorageQN.LeastChange

open InnerProductSpace

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H]

/-- Membership in the Hilbert–Schmidt class, tested on an arbitrary Hilbert basis. -/
def HSSummable {ι : Type*} (b : HilbertBasis ι ℝ H) (B : H →L[ℝ] H) : Prop :=
  Summable fun i => ‖B (b i)‖ ^ 2

/-- The sum (A.1); used as a norm only when `HSSummable b B`. -/
noncomputable def hsNorm {ι : Type*} (b : HilbertBasis ι ℝ H) (B : H →L[ℝ] H) : ℝ :=
  Real.sqrt (∑' i, ‖B (b i)‖ ^ 2)

end VarStorageQN.LeastChange
