import Mathlib

namespace VarStorageQN.LeastChange

open InnerProductSpace
open scoped InnerProductSpace

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- The bracket operator `[u,v] d = ⟪v,d⟫ u` (§2.1, p. 3). -/
noncomputable abbrev bracket (u v : H) : H →L[ℝ] H := rankOne ℝ u v

/-- "B is positive" in the paper's strict sense (§2.1, p. 3):
`⟪B u, u⟫ > 0` for every nonzero `u`. -/
def IsPositiveStrict (B : H →L[ℝ] H) : Prop := ∀ u : H, u ≠ 0 → 0 < ⟪B u, u⟫_ℝ

end VarStorageQN.LeastChange
