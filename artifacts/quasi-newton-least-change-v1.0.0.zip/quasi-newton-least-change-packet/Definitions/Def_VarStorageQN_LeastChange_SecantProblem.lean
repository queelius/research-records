import Mathlib
import Definitions.Def_VarStorageQN_LeastChange_HilbertSchmidt

namespace VarStorageQN.LeastChange

open InnerProductSpace ContinuousLinearMap
open scoped InnerProductSpace

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H] [CompleteSpace H]

/-- The feasible Hilbert–Schmidt perturbations Π of (A.4). -/
def Feas {ι : Type*} (b : HilbertBasis ι ℝ H) (B : H →L[ℝ] H) (y s : H) :
    Set (H →L[ℝ] H) :=
  {P | HSSummable b P ∧ (B + P) s = y}

/-- The feasible self-adjoint Hilbert–Schmidt perturbations Π_S of (A.6). -/
def FeasSym {ι : Type*} (b : HilbertBasis ι ℝ H) (B : H →L[ℝ] H) (y s : H) :
    Set (H →L[ℝ] H) :=
  {P | HSSummable b P ∧ IsSelfAdjoint P ∧ (B + P) s = y}

/-- The weight `c = R^{-*} R^{-1} s` in Propositions A.1 and A.2. -/
noncomputable def weight (R : H ≃L[ℝ] H) (s : H) : H :=
  adjoint (R.symm : H →L[ℝ] H) (R.symm s)

end VarStorageQN.LeastChange
