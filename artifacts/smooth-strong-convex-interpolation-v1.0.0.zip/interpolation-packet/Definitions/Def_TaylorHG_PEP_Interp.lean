import Mathlib
import Definitions.Def_ShorNonsmooth_AlmostDiff_IsSubgradient

namespace TaylorHG.PEP

/-- Definition 1: the real-valued version of the paper's class. -/
def FClass {d : ℕ} (μ : NNReal) (L : ENNReal)
    (f : EuclideanSpace ℝ (Fin d) → ℝ) : Prop :=
  ConvexOn ℝ Set.univ f ∧
  (∀ x₁ x₂ g₁ g₂, ShorNonsmooth.AlmostDiff.IsSubgradient f x₁ g₁ →
    ShorNonsmooth.AlmostDiff.IsSubgradient f x₂ g₂ →
    (L⁻¹).toReal * ‖g₁ - g₂‖ ≤ ‖x₁ - x₂‖) ∧
  ConvexOn ℝ Set.univ (fun x => f x - (μ : ℝ) / 2 * ‖x‖ ^ 2)

/-- Definition 2: finite data interpolated by a member of `FClass`. -/
def Interpolable {d : ℕ} {ι : Type*} [Fintype ι] (μ : NNReal) (L : ENNReal)
    (x g : ι → EuclideanSpace ℝ (Fin d)) (fv : ι → ℝ) : Prop :=
  ∃ f : EuclideanSpace ℝ (Fin d) → ℝ,
    FClass μ L f ∧ ∀ i, f (x i) = fv i ∧
      ShorNonsmooth.AlmostDiff.IsSubgradient f (x i) (g i)

/-- The ordered-pair condition (4), with the paper's convention at `L = ∞`. -/
def InterpIneq {d : ℕ} {ι : Type*} (μ : NNReal) (L : ENNReal)
    (x g : ι → EuclideanSpace ℝ (Fin d)) (fv : ι → ℝ) (i j : ι) : Prop :=
  let ℓ := (L⁻¹).toReal
  (1 / (2 * (1 - (μ : ℝ) * ℓ))) *
    (ℓ * ‖g i - g j‖ ^ 2 + (μ : ℝ) * ‖x i - x j‖ ^ 2 -
      2 * ((μ : ℝ) * ℓ) * inner ℝ (g j - g i) (x j - x i)) ≤
    fv i - fv j - inner ℝ (g j) (x i - x j)

end TaylorHG.PEP
