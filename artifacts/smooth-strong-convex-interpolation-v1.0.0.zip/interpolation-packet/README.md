# Smooth strongly convex interpolation: reproducible formalization

Version 1.0.0 · [10.5281/zenodo.23496220](https://doi.org/10.5281/zenodo.23496220)

This packet contains one complete accepted Lean proof of the real-valued
interpolation criterion of Taylor, Hendrickx and Glineur. Read [NOTE.md](NOTE.md)
for the exact claim, proof outline, attribution and limits. The contribution is
formalization of established mathematics; independent human review and
mathematical novelty are not claimed.

## Reproduce

On Linux/POSIX, install Python 3.10+, Git and the Lean `elan` toolchain manager.
From this extracted packet's root:

```sh
python3 scripts/verify_archive.py --integrity-only
python3 scripts/verify_archive.py --setup
```

The first command checks recorded hashes, receipts and pins without Lean or
network access. The second obtains Lean 4.33.1 and the pinned transitive
dependencies, downloads their compiled cache, rebuilds both platform definition
modules, and compiles the exact-type and axiom audit. First setup requires network
access and several GB of disk space. No Prove2Me account or credentials are used.
Subsequent runs can omit `--setup`. A passing JSON report contains one target
with `"compiled": true`, and only `propext`, `Classical.choice` and `Quot.sound`.

The archive verifier is unchanged from the pinned development commit. See
[verification/README.md](verification/README.md) for explicit cache reuse.
That general verifier documentation also describes the larger private archive;
this curated packet contains only the interpolation target and its two
definition modules. Third-party compiled caches are trusted inputs. The packet
does not contain a bootstrap verification of Lean or Mathlib.

## Inspect the evidence

- `contributions/queelius/proofs/TaylorHG_PEP_theorem_4.lean`: exact accepted bytes.
- `contributions/queelius/evidence/checks/`: accepted proof followed by an
  independent full target signature and local-declaration/axiom guards.
- `contributions/queelius/contributions.json`: one-target excerpt of the owning
  project's ledger, with scope and predecessor credit.
- `Definitions/`: byte-exact public platform definitions.
- `verification/receipt.json`: staged-packet reproduction and rejection controls.
- `verification/controls/`: intentionally invalid input and failure evidence;
  these files are excluded from the accepted proof and source manifest.
- `provenance.json`: source pins, public disclosure, acceptance and licensing.
- `MANIFEST.json`: SHA-256 and size of every other packet file.

The original target JSON records its unproved statement using the platform's
`by sorry` placeholder. That JSON is evidence of the requested type, never a
compiled dependency. The accepted Lean source and audited definitions contain
no such placeholder. The negative axiom control is explicitly invalid and must
fail; it is not a mathematical contribution.

Historical compiler logs and commands have local filesystem prefixes replaced
with portable labels. The raw log hash and the redaction are recorded explicitly.
Proof, audit, definition and environment-pin bytes are preserved exactly.
Publication, platform acceptance and local reproduction are distinct events.

## License and citation

Apache License 2.0; see [LICENSE](LICENSE) and [NOTICE.md](NOTICE.md). Cite the
exact archival version using [CITATION.cff](CITATION.cff), and cite Taylor,
Hendrickx and Glineur for the mathematical theorem.
