import Lean.Elab.Import

/- Use Lean's header parser; comments, escaped identifiers, and multi-import
   commands must have the same meaning here as they do in the compiler. -/
def main (args : List String) : IO UInt32 := do
  let mut rows : Array Lean.Json := #[]
  for path in args do
    let source ← IO.FS.readFile path
    let (imports, _, messages) ← Lean.Elab.parseImports source (some path)
    if messages.hasErrors then
      throw (IO.userError s!"Invalid Lean import header: {path}")
    rows := rows.push (Lean.Json.mkObj [
      ("path", Lean.Json.str path),
      ("imports", Lean.Json.arr (imports.map fun i => Lean.Json.str i.module.toString))])
  IO.println (Lean.Json.arr rows).compress
  return 0
