# Reproduce the contribution archive

From a fresh checkout, run:

```bash
python3 scripts/verify_archive.py --setup --report .local/archive-verification/report.json
```

Runtime requirements are Python 3.10+, Linux/POSIX, Git, and `elan` on `PATH`.
Setup installs Lean 4.33.1 if needed, fetches the exact Git revisions in the
tracked transitive manifest, and runs Mathlib's cache downloader for the imported
Mathlib modules. It may build the cache downloader itself. It never runs
`lake update` or asks Lake to rebuild Mathlib from source. The first setup needs
network access and several GB of disk space. If a required cached module is
unavailable, verification fails with its compiler log instead of rebuilding it.

A later run reuses the isolated environment:

```bash
python3 scripts/verify_archive.py --report .local/archive-verification/report.json
```

`--work-dir PATH` relocates the environment and run outputs. A fresh setup is
stored beneath that directory, never in the checkout's root `.lake`. A POSIX
file lock serializes setup; each verification gets a unique snapshot and output
directory. If setup is interrupted during a dependency fetch, retain its report
and use a new `--work-dir` for another clean attempt.

To check portable evidence without Lean, Git, or network access:

```bash
python3 scripts/verify_archive.py --integrity-only
```

This validates unique target IDs, accepted receipt relationships, proof/audit/log
hashes, exact proof byte prefixes, environment pins, transitive dependency pins,
and the platform-source manifest. Its report labels every target
`"compiled": false`; it does not claim a new proof check.

## Reuse an existing compiler and cache

External reuse is explicit and read-only:

```bash
python3 scripts/verify_archive.py \
  --compiler /path/to/lean-4.33.1/bin/lean \
  --mathlib /path/to/packages/mathlib \
  --cache-dir /path/to/verified-mathlib-cache/lib/lean \
  --cache-dir /path/to/packages/batteries/.lake/build/lib/lean \
  --cache-dir /path/to/packages/Qq/.lake/build/lib/lean \
  --cache-dir /path/to/packages/aesop/.lake/build/lib/lean \
  --cache-dir /path/to/packages/proofwidgets/.lake/build/lib/lean \
  --cache-dir /path/to/packages/importGraph/.lake/build/lib/lean \
  --cache-dir /path/to/packages/LeanSearchClient/.lake/build/lib/lean \
  --cache-dir /path/to/packages/plausible/.lake/build/lib/lean
```

Include each existing compiled dependency root needed by the imported modules.
The package checkout directories must be siblings of `mathlib`, named as in the
pinned manifest. Their exact Git revisions are checked, including packages whose
compiled root is unnecessary for this proof corpus. Cache roots containing
`Definitions/` or `Theorems/` are rejected so old platform modules cannot substitute
for the archived source. The program replaces inherited `LEAN_PATH` with its fresh
output directory followed by these explicit dependency roots. It never writes to
external caches or package checkouts. Their compiled artifacts remain a trusted
input; a matching source revision alone is not an attestation of a cached binary.

## What a passing compilation report establishes

The program freezes each accepted source, archived audit, and platform module as
bytes. It derives import edges using `Lean.Elab.parseImports` in
[Imports.lean](Imports.lean), then compiles reachable platform modules in dependency
order with `autoImplicit=false`. This includes the accepted positivity dependency
credited to Eyal1990 in the contribution ledger. No module order or theorem ID is
hardcoded in the verifier.

Each frozen audit contains its accepted proof as an exact byte prefix and an
independent exact-type example copied from the archived target. An additional
transitive `Lean.collectAxioms` guard rejects axioms outside `propext`,
`Classical.choice`, and `Quot.sound` in the pinned environment. The JSON report
records per-target proof/audit/evidence hashes, a compiled-audit hash, the exact
compiler version, all dependency revisions, the generated import graph, compiler
commands, log hashes, and exit codes. A failed command leaves a failed report and
its log. Source mutation during compilation prevents a passing result.

The archived exact-type examples are reviewed inputs. The tool recompiles them;
it does not mechanically synthesize an exact statement from platform JSON. Local
reproduction does not refresh server verdicts, establish mathematical novelty,
or assert independent human review. It does not read credentials or contact the
Prove2Me API. The accepted proof files and historical evidence remain unchanged.

## Pins and tests

[environments/lean-4.33.1.json](environments/lean-4.33.1.json) names the pinned setup
files and [platform-sources.json](platform-sources.json) records the platform-source
hashes. New environment pins belong in explicit manifests and require their own
verification. Do not edit an existing accepted source to make a new environment
compile.

```bash
python3 -m pytest -q
python3 -m coverage run -m pytest -q
python3 -m coverage combine
python3 -m coverage report -m
```

`tests/test_archive.py` exercises source/evidence integrity, path and pin rejection,
real Lean import parsing when Lean is installed, dependency ordering and cycles,
compiler failure evidence, transitive axiom rejection, fresh outputs, mutation
handling, and clean-setup pin preservation. Ordinary Python tests simulate the
external compiler/network boundary; the separate real archive command is the
end-to-end proof check. No coverage threshold is configured.
