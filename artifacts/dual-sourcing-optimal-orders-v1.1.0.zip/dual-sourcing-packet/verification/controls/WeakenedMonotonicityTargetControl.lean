import Mathlib
import Definitions.Def_MitigateSupplyRisk_DualSourcing_Model

open MeasureTheory ProbabilityTheory
open MitigateSupplyRisk.DualSourcing
set_option autoImplicit false
theorem solution (M : Model) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ0 : μ (Set.Iio 0) = 0) (hμint : Integrable id μ) (i : Fin 2)
    (a : Fin 2 → ℝ) : True := by trivial

example (M : MitigateSupplyRisk.DualSourcing.Model) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ0 : μ (Set.Iio 0) = 0) (hμint : Integrable id μ) (i : Fin 2) (a : Fin 2 → ℝ) :
    Monotone (fun t : ℝ => M.Pi2star μ (Function.update a i t)) :=
  solution M μ hμ0 hμint i a


-- Generated proof_workflow guard; keep the independent audit above.
run_cmd do
  let env ← Lean.getEnv
  let some info := env.find? `solution | throwError "Missing top-level solution"
  unless info.isTheorem do throwError "solution must be a theorem"
  if env.isImportedConst `solution then throwError "solution must be local"
  let forbidden : String := "Theorems.Thm_MitigateSupplyRisk_DualSourcing_lemma_2b"
  for moduleName in env.header.moduleNames do
    if moduleName.toString == forbidden then throwError "Circular target import"
  let allowed : Array Lean.Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let localDecls := env.constants.foldStage2 (fun xs n c => xs.push (n, c)) #[]
  for (name, decl) in localDecls do
    if !env.isImportedConst name then
      if decl.isAxiom then throwError "Local axiom is forbidden: {name}"
      for axiomName in (← Lean.collectAxioms name) do
        unless allowed.contains axiomName do
          throwError "Unexpected axiom in local declaration: {axiomName}"
  let axioms ← Lean.collectAxioms `solution
  for axiomName in axioms do
    unless allowed.contains axiomName do
      throwError "Unexpected axiom in solution: {axiomName}"
  let data := Lean.Json.arr (axioms.map fun n => Lean.Json.str n.toString)
  IO.println ("PROOF_WORKFLOW_AXIOMS 802352b127144936bca91ffa40a7d1d3 " ++ data.compress)
