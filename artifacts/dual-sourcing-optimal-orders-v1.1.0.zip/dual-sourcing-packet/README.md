# Verified dual-sourcing profit structure, orders and reliability

Version 1.1.0 · [10.5281/zenodo.23533755](https://doi.org/10.5281/zenodo.23533755). Identifiers were reserved during assembly; the separate publication receipt establishes public availability. NOTE.md states all four complete results, exact assumptions,
proof ideas, source correspondence, attribution and limits. This successor
preserves the earlier two proofs and adds Equation (6) and Lemma 2(b).
The original mathematics is by Yimin Wang, Wendell Gilland and Brian Tomlin.

## Reproduce

From this directory on Linux/POSIX with Python 3.10+, Git and elan:

```sh
python3 scripts/verify_archive.py --integrity-only
python3 scripts/verify_archive.py --setup
```

First setup needs network and several GB of disk, but no platform credentials.
Expected: four compiled full-target audits, one fresh platform definition,
autoImplicit=false and only propext, Classical.choice and Quot.sound.
Verified pinned third-party caches are trusted inputs. See verification/README.md.

## Evidence and scope

Accepted proof/audit bytes are unchanged. All required platform sources,
receipt hashes, independent exact types and licenses are included. Historical
filesystem prefixes are normalized with original hashes retained. Target JSON
contains by-sorry placeholders only as original statement text, not proofs.
Five intentionally invalid controls test the axiom guard, three exact target
interfaces and proof-byte integrity; all must reject and were never submitted.

MANIFEST.json inventories every file except itself. The previous published
edition is preserved under versions/1.0.0, including its unchanged archive.
Version 1.0.0 remains citable through DOI 10.5281/zenodo.23531695. This publication
adds no platform target. Sufficient first-order conditions, optimizer regions,
optimal-quantity ordering and the wider mission remain separate obligations.
No mathematical novelty, author endorsement or human proof review is claimed.
