# Intentionally invalid controls

These files are excluded from accepted proof and definition manifests.
ExtraAxiomControl retains the complete accepted optimizer proof and exact-target
audit but inserts an unused False axiom immediately before the original guard.
The guard must reject even an unused local axiom.

WeakenedTargetControl replaces the candidate with a proof of True while retaining
the entire independent optimizer target audit and guards. It must fail at the
exact-target application. This checks that a trivial weaker proposition cannot
stand in for the quantified optimizer theorem.

The byte-mutation control copies the packet, appends a newline to one accepted
proof and runs its unchanged integrity verifier. It must reject the hash change.
No invalid control was submitted to Prove2Me. Compiler errors and exit codes
are preserved alongside the receipt.
