import Mathlib
import Definitions.Def_ConstrNestedLogit_Space_Model

theorem solution : True := by
  trivial

namespace ConstrNestedLogit.Space

/-- The greedy LP relaxation of (10) can be chosen with at most one fractional coordinate. -/
theorem exact_target {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (I : NestedLogitVariants.LP.Instance ι n)
    (w : ι → Fin n → ℝ) (c : ι → ℝ) (i : ι)
    (hn : 0 < n)
    (hvnp : ∀ i, I.vnp i = 0) (hv : ∀ j, 0 < I.v i j)
    (hw : ∀ j, 0 < w i j) (hwc : ∀ j, w i j ≤ c i)
    (u : ℝ) (hu : 0 ≤ u) :
    ∃ x : Fin n → ℝ, spaceLPOptimal I w c i u x ∧ atMostOneFractional x ∧
      (∀ j, 0 < x j → 0 < utility I i u j) ∧
      (∀ j k, 0 < x j → x k < 1 →
        utilityRatio I w i u k ≤ utilityRatio I w i u j) := by
  exact solution I w c i hn hvnp hv hw hwc u hu

end ConstrNestedLogit.Space

#print axioms ConstrNestedLogit.Space.exact_target


-- Generated proof_workflow guard; keep the independent audit above.
run_cmd do
  let env ← Lean.getEnv
  let some info := env.find? `solution | throwError "Missing top-level solution"
  unless info.isTheorem do throwError "solution must be a theorem"
  if env.isImportedConst `solution then throwError "solution must be local"
  let forbidden : String := "Theorems.Thm_ConstrNestedLogit_Space_greedy_lp"
  for moduleName in env.header.moduleNames do
    if moduleName.toString == forbidden then throwError "Circular target import"
  let allowed : Array Lean.Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let localDecls := env.constants.foldStage2 (fun xs n c => xs.push (n, c)) #[]
  for (name, decl) in localDecls do
    if !env.isImportedConst name then
      if decl.isAxiom then throwError "Local axiom is forbidden: {name}"
      for axiomName in (← Lean.collectAxioms name) do
        unless allowed.contains axiomName do
          throwError "Unexpected axiom in local declaration: {axiomName}"
  let axioms ← Lean.collectAxioms `solution
  for axiomName in axioms do
    unless allowed.contains axiomName do
      throwError "Unexpected axiom in solution: {axiomName}"
  let data := Lean.Json.arr (axioms.map fun n => Lean.Json.str n.toString)
  IO.println ("PROOF_WORKFLOW_AXIOMS 5bb9771e41c643e0bb62db1785a2baea " ++ data.compress)
