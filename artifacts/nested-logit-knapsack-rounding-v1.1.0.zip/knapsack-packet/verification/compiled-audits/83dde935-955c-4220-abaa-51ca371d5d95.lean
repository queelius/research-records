import Mathlib
import Definitions.Def_ConstrNestedLogit_Space_Model

open scoped BigOperators
open ConstrNestedLogit.Space

namespace KnapsackRounding

lemma support_nonneg {n : ℕ} (w a x : Fin n → ℝ) (c : ℝ)
    (hw : ∀ k, 0 ≤ w k) (hx : knapsackLPOptimal w a c x)
    (k : Fin n) (hk : 0 < x k) : 0 ≤ a k := by
  classical
  by_contra ha
  have ha : a k < 0 := lt_of_not_ge ha
  let y : Fin n → ℝ := fun l => if l = k then 0 else x l
  have hy : knapsackLPFeasible w c y := by
    constructor
    · intro l
      by_cases hl : l = k
      · simp [y, hl]
      · simpa [y, hl] using hx.1.1 l
    · apply le_trans _ hx.1.2
      apply Finset.sum_le_sum
      intro l hl
      by_cases hlk : l = k
      · subst l
        simpa [y] using mul_nonneg (hw k) (hx.1.1 k).1
      · simp [y, hlk]
  have hs : knapsackLPObjective a x < knapsackLPObjective a y := by
    apply Finset.sum_lt_sum
    · intro l hl
      by_cases hlk : l = k
      · subst l
        simp only [y, if_pos rfl, mul_zero]
        exact le_of_lt (mul_neg_of_neg_of_pos ha hk)
      · simp [y, hlk]
    · exact ⟨k, Finset.mem_univ k, by simpa [y] using mul_neg_of_neg_of_pos ha hk⟩
  exact (not_lt_of_ge (hx.2 y hy)) hs

lemma objective_split {n : ℕ} (a x : Fin n → ℝ)
    (hx : ∀ k, 0 ≤ x k ∧ x k ≤ 1) (j : Option (Fin n))
    (hj : ∀ k, (0 < x k ∧ x k < 1) ↔ j = some k) :
    knapsackLPObjective a x =
      (∑ k ∈ rounded x, a k) +
        (match j with | none => 0 | some k => a k * x k) := by
  classical
  have hbin (k : Fin n) (hk : j ≠ some k) : x k = 0 ∨ x k = 1 := by
    by_contra h
    have h0 : x k ≠ 0 := fun h0 => h (Or.inl h0)
    have h1 : x k ≠ 1 := fun h1 => h (Or.inr h1)
    exact hk ((hj k).mp ⟨lt_of_le_of_ne (hx k).1 (Ne.symm h0),
      lt_of_le_of_ne (hx k).2 h1⟩)
  cases j with
  | none =>
    simp only [add_zero, knapsackLPObjective, rounded, Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro k hk
    rcases hbin k (by simp) with h | h <;> simp [h]
  | some k =>
    have hk := (hj k).mpr rfl
    have heq (l : Fin n) :
        a l * x l = (if x l = 1 then a l else 0) +
          (if l = k then a k * x k else 0) := by
      by_cases hl : l = k
      · subst l
        simp [ne_of_lt hk.2]
      · rcases hbin l (by simpa using Ne.symm hl) with h | h <;> simp [h, hl]
    simp only [knapsackLPObjective, rounded, Finset.sum_filter]
    calc
      _ = ∑ l, ((if x l = 1 then a l else 0) +
          (if l = k then a k * x k else 0)) := Finset.sum_congr rfl (fun l _ => heq l)
      _ = _ := by rw [Finset.sum_add_distrib]; simp

lemma integer_le_lp {n : ℕ} (w a x : Fin n → ℝ) (c : ℝ)
    (hx : knapsackLPOptimal w a c x)
    (T : Finset (Fin n)) (hT : ∑ k ∈ T, w k ≤ c) :
    (∑ k ∈ T, a k) ≤ knapsackLPObjective a x := by
  classical
  let y : Fin n → ℝ := fun k => if k ∈ T then 1 else 0
  have hy : knapsackLPFeasible w c y := by
    constructor
    · intro k
      by_cases hk : k ∈ T <;> simp [y, hk]
    · simpa [y, mul_ite] using hT
  simpa [knapsackLPObjective, y, mul_ite] using hx.2 y hy

end KnapsackRounding

theorem solution {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (I : NestedLogitVariants.LP.Instance ι n)
    (w : ι → Fin n → ℝ) (c : ι → ℝ) (i : ι)
    (hvnp : ∀ i, I.vnp i = 0) (hv : ∀ j, 0 < I.v i j)
    (hw : ∀ j, 0 < w i j) (hwc : ∀ j, w i j ≤ c i)
    (u : ℝ) (hu : 0 ≤ u) (x : Fin n → ℝ)
    (hx : spaceLPOptimal I w c i u x) (j : Option (Fin n))
    (hj : ∀ k, (0 < x k ∧ x k < 1) ↔ j = some k) :
    ∀ T : Finset (Fin n), spaceFeasible w c i T →
      assortmentUtility I i u T ≤
        2 * max (assortmentUtility I i u (rounded x))
          (match j with | none => 0 | some k => utility I i u k) := by
  intro T hT
  have hbound := KnapsackRounding.integer_le_lp (w i) (utility I i u) x (c i) hx T hT
  have hsplit := KnapsackRounding.objective_split (utility I i u) x hx.1.1 j hj
  change assortmentUtility I i u T ≤ _ at hbound
  change knapsackLPObjective (utility I i u) x =
    assortmentUtility I i u (rounded x) + _ at hsplit
  cases j with
  | none =>
    simp only [add_zero] at hsplit
    have hmax := le_max_left (assortmentUtility I i u (rounded x)) (0 : ℝ)
    have hnonneg := le_max_right (assortmentUtility I i u (rounded x)) (0 : ℝ)
    dsimp
    linarith
  | some k =>
    have hk := (hj k).mpr rfl
    have ha := KnapsackRounding.support_nonneg (w i) (utility I i u) x (c i)
      (fun l => (hw l).le) hx k hk.1
    have hprod : utility I i u k * x k ≤ utility I i u k :=
      mul_le_of_le_one_right ha (hx.1.1 k).2
    have hmax₁ := le_max_left (assortmentUtility I i u (rounded x)) (utility I i u k)
    have hmax₂ := le_max_right (assortmentUtility I i u (rounded x)) (utility I i u k)
    dsimp at hsplit ⊢
    linarith

#print axioms solution

namespace ConstrNestedLogit.Space

/-- Equation (11), with an optional fractional coordinate. -/
theorem exact_target {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (I : NestedLogitVariants.LP.Instance ι n)
    (w : ι → Fin n → ℝ) (c : ι → ℝ) (i : ι)
    (hvnp : ∀ i, I.vnp i = 0) (hv : ∀ j, 0 < I.v i j)
    (hw : ∀ j, 0 < w i j) (hwc : ∀ j, w i j ≤ c i)
    (u : ℝ) (hu : 0 ≤ u) (x : Fin n → ℝ)
    (hx : spaceLPOptimal I w c i u x) (j : Option (Fin n))
    (hj : ∀ k, (0 < x k ∧ x k < 1) ↔ j = some k) :
    ∀ T : Finset (Fin n), spaceFeasible w c i T →
      assortmentUtility I i u T ≤
        2 * max (assortmentUtility I i u (rounded x))
          (match j with | none => 0 | some k => utility I i u k) := by
  exact solution I w c i hvnp hv hw hwc u hu x hx j hj

end ConstrNestedLogit.Space



-- Generated proof_workflow guard; keep the independent audit above.
run_cmd do
  let env ← Lean.getEnv
  let some info := env.find? `solution | throwError "Missing top-level solution"
  unless info.isTheorem do throwError "solution must be a theorem"
  if env.isImportedConst `solution then throwError "solution must be local"
  let forbidden : String := "Theorems.Thm_ConstrNestedLogit_Space_equation_11"
  for moduleName in env.header.moduleNames do
    if moduleName.toString == forbidden then throwError "Circular target import"
  let allowed : Array Lean.Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let localDecls := env.constants.foldStage2 (fun xs n c => xs.push (n, c)) #[]
  for (name, decl) in localDecls do
    if !env.isImportedConst name then
      if decl.isAxiom then throwError "Local axiom is forbidden: {name}"
      for axiomName in (← Lean.collectAxioms name) do
        unless allowed.contains axiomName do
          throwError "Unexpected axiom in local declaration: {axiomName}"
  let axioms ← Lean.collectAxioms `solution
  for axiomName in axioms do
    unless allowed.contains axiomName do
      throwError "Unexpected axiom in solution: {axiomName}"
  let data := Lean.Json.arr (axioms.map fun n => Lean.Json.str n.toString)
  IO.println ("PROOF_WORKFLOW_AXIOMS 0d9c3d21d8fb4017ab000cc7c68aba63 " ++ data.compress)

-- Fresh transitive axiom guard added by the archive verifier.
run_cmd do
  let allowed : Array Lean.Name := #[("propext".toName), ("Classical.choice".toName), ("Quot.sound".toName)]
  let axioms ← Lean.collectAxioms `solution
  for axiomName in axioms do
    unless allowed.contains axiomName do
      throwError "Unexpected axiom in solution: {axiomName}"
  let data := Lean.Json.arr (axioms.map fun n => Lean.Json.str n.toString)
  IO.println ("ARCHIVE_AXIOMS_JSON " ++ data.compress)
