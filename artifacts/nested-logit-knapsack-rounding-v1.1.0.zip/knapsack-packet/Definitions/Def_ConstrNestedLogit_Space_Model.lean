import Mathlib
import Definitions.Def_NestedLogitVariants_LP_Model
import Definitions.Def_ConstrNestedLogit_Space_KnapsackLP

namespace ConstrNestedLogit.Space

variable {ι : Type*} {n : ℕ}

/-- Space feasibility in nest `i` (p. 8): `S ∈ C_i` iff `∑_{j ∈ S} w_ij ≤ c_i`. -/
def spaceFeasible (w : ι → Fin n → ℝ) (c : ι → ℝ) (i : ι)
    (S : Finset (Fin n)) : Prop :=
  (∑ j ∈ S, w i j) ≤ c i

/-- Product utility in (10) at the parameter `u`. -/
def utility (I : NestedLogitVariants.LP.Instance ι n) (i : ι) (u : ℝ) (j : Fin n) : ℝ :=
  I.v i j * (I.r i j - u)

/-- The utility per unit of space, `f_ij(u) = v_ij (r_ij − u) / w_ij` on p. 19. It is the paper's
ratio only when `w_ij > 0`, which the theorems assume (`x / 0 = 0` in Lean). -/
noncomputable def utilityRatio (I : NestedLogitVariants.LP.Instance ι n)
    (w : ι → Fin n → ℝ) (i : ι) (u : ℝ) (j : Fin n) : ℝ :=
  utility I i u j / w i j

/-- Objective of the integer knapsack (10), equal to (7) when `vnp = 0`. -/
def assortmentUtility (I : NestedLogitVariants.LP.Instance ι n) (i : ι) (u : ℝ)
    (S : Finset (Fin n)) : ℝ :=
  ∑ j ∈ S, utility I i u j

/-- `x ∈ [0,1]^n` is an optimal solution of the linear programming relaxation of (10) at `u`. -/
def spaceLPOptimal (I : NestedLogitVariants.LP.Instance ι n)
    (w : ι → Fin n → ℝ) (c : ι → ℝ) (i : ι) (u : ℝ) (x : Fin n → ℝ) : Prop :=
  knapsackLPOptimal (w i) (utility I i u) (c i) x

/-- The assortment obtained by rounding the LP solution down, `S_ij = ⌊x_ij⌋` (p. 20); for
`x ∈ [0,1]^n` this is the set of products with `x_j = 1`. -/
noncomputable def rounded (x : Fin n → ℝ) : Finset (Fin n) :=
  Finset.univ.filter (fun j => x j = 1)

/-- `x_j` is the fractional component `j^g` of `x` (p. 20), and every other component is `0` or `1`. -/
def oneFractional (x : Fin n → ℝ) (j : Fin n) : Prop :=
  0 < x j ∧ x j < 1 ∧ ∀ k, k ≠ j → x k = 0 ∨ x k = 1

/-- At most one component lies strictly between zero and one. -/
def atMostOneFractional (x : Fin n → ℝ) : Prop :=
  ∀ j k, 0 < x j → x j < 1 → 0 < x k → x k < 1 → j = k

/-- The candidate family `{S_i^g : g ∈ G_i} ∪ {{j} : j ∈ N}` of p. 20, described by its members:
it contains the empty assortment (the rounding of the LP optimum `x = 0` for large `u`) and every
singleton, and each member is a singleton or the rounding of an optimal solution of the LP
relaxation of (10) with at most one fractional component, at some `u ≥ 0`. -/
def isRoundedCandidateFamily (I : NestedLogitVariants.LP.Instance ι n)
    (w : ι → Fin n → ℝ) (c : ι → ℝ) (i : ι)
    (A : Finset (Finset (Fin n))) : Prop :=
  (∅ ∈ A) ∧ (∀ j, ({j} : Finset (Fin n)) ∈ A) ∧
  ∀ S ∈ A, (∃ j, S = {j}) ∨
    ∃ u : ℝ, 0 ≤ u ∧ ∃ x : Fin n → ℝ,
      spaceLPOptimal I w c i u x ∧ atMostOneFractional x ∧ S = rounded x

/-- `S` is an `α`-approximate solution to problem (7) at `u` under space constraints, in the form
of (5) (p. 13): `S ∈ C_i` and `α · V_i(S)(R_i(S) − u) ≥ V_i(T)(R_i(T) − u)` for every `T ∈ C_i`. -/
def isApproximateAt (I : NestedLogitVariants.LP.Instance ι n)
    (w : ι → Fin n → ℝ) (c : ι → ℝ) (i : ι) (u α : ℝ)
    (S : Finset (Fin n)) : Prop :=
  spaceFeasible w c i S ∧
    ∀ T, spaceFeasible w c i T →
      NestedLogitVariants.LP.V I i T * (NestedLogitVariants.LP.R I i T - u) ≤
        α * (NestedLogitVariants.LP.V I i S * (NestedLogitVariants.LP.R I i S - u))

end ConstrNestedLogit.Space
