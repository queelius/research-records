import Mathlib

namespace ConstrNestedLogit.Space

/-- Feasible points of the continuous relaxation of a finite 0–1 knapsack. -/
def knapsackLPFeasible {n : ℕ} (w : Fin n → ℝ) (c : ℝ) (x : Fin n → ℝ) : Prop :=
  (∀ j, 0 ≤ x j ∧ x j ≤ 1) ∧ (∑ j, w j * x j) ≤ c

/-- Linear objective of the continuous knapsack relaxation. -/
def knapsackLPObjective {n : ℕ} (a : Fin n → ℝ) (x : Fin n → ℝ) : ℝ :=
  ∑ j, a j * x j

/-- An optimal point of the continuous knapsack relaxation. -/
def knapsackLPOptimal {n : ℕ} (w a : Fin n → ℝ) (c : ℝ) (x : Fin n → ℝ) : Prop :=
  knapsackLPFeasible w c x ∧
    ∀ y, knapsackLPFeasible w c y → knapsackLPObjective a y ≤ knapsackLPObjective a x

end ConstrNestedLogit.Space
