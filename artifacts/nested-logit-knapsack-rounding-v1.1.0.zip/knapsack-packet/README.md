# Fractional-knapsack construction and rounding bounds

Version 1.1.0 · [10.5281/zenodo.23526994](https://doi.org/10.5281/zenodo.23526994).

Identifiers were reserved during assembly; the central publication receipt
records actual publication and public-download verification.

This packet contains three complete accepted Lean proofs of
established Gallego–Topaloglu mathematics: optimizer construction, factor-two
rounding and the refined small-item utility bound. See NOTE.md for the argument,
record.json for exact targets/credit, and provenance.json for source pins.
The uniform candidate-family bound and full assortment-revenue theorem remain
open and are not included as completed results.

## Reproduce

On Linux/POSIX, use Python 3.10+, Git and the elan Lean toolchain manager.
From the extracted packet root:

```sh
python3 scripts/verify_archive.py --integrity-only
python3 scripts/verify_archive.py --setup
```

The first command checks hashes, receipts and dependency pins without Lean
or a network. The second obtains Lean 4.33.1 and immutable Mathlib/transitive
dependency revisions, downloads compiled caches, freshly builds all three
platform modules, and checks all three complete target/axiom audits with
autoImplicit=false. First setup needs network access and several GB of disk.
No Prove2Me account or credentials are required. Subsequent runs can omit
--setup; verification/README.md explains explicit verified-cache reuse.

A successful JSON report has status passed, three targets with compiled true,
and only propext, Classical.choice and Quot.sound as axioms. Third-party
compiled caches are trusted inputs; this is not a bootstrap check of Lean
or Mathlib. The verifier is unchanged from the source commit in provenance.json.

## Evidence and controls

Exact accepted proofs are under contributions/queelius/proofs/. Each audit
in evidence/checks/ includes the accepted proof as an exact byte prefix, a
complete independent target signature and guards against local/unapproved
axioms and circular target imports. Definitions/ contains all platform
dependencies; no open theorem placeholder is imported. The target JSON may
contain the platform's by-sorry statement placeholder as historical text.

verification/receipt.json records the fresh staged-packet reproduction and
intentionally rejected controls. Invalid controls are excluded from accepted
sources and must fail; they were never submitted. Historical command/log
filesystem prefixes are normalized to portable labels, with original and
normalized hashes retained. Proof/audit/definition bytes are unchanged.
MANIFEST.json inventories every packet file except the manifest itself.

## Credit and citation

Cite the exact archival version using CITATION.cff and cite Gallego/Topaloglu
for the underlying mathematics. Alexander Richard Towell directed; OpenAI
Codex substantially formalized, verified and documented; prior platform and
Lean/Mathlib contributors retain credit in NOTICE.md. Formal verification,
platform acceptance, public disclosure, archival publication and human review
are separately dated/qualified. See LICENSE, LICENSE-METADATA and NOTICE.md.
