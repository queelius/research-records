import Mathlib
import Definitions.Def_CompetingChains_Cournot_Setting
set_option autoImplicit false
theorem solution : True := by trivial

example (γ t σsq : ℝ) (hγ0 : 0 < γ) (hγ1 : γ < 1) (ht : 0 < t) (hσ : 0 < σsq) :
    ∃ kN kS : ℝ, 1 / 2 < kN ∧ kN < kS ∧ kS < (3 + Real.sqrt 5) / 4 ∧
      ∀ a c k : ℝ, Standing a c k γ t σsq →
        (k < kN → equilibria a c k γ t σsq = {(.S, .S)}) ∧
        (kN < k → k < kS →
          equilibria a c k γ t σsq = {(.S, .S), (.N, .N)} ∧
            payoff a c k γ t σsq .N .N < payoff a c k γ t σsq .S .S) ∧
        (kS < k → equilibria a c k γ t σsq = {(.N, .N)})  := solution γ t σsq hγ0 hγ1 ht hσ
#print axioms solution


-- Generated proof_workflow guard; keep the independent audit above.
run_cmd do
  let env ← Lean.getEnv
  let some info := env.find? `solution | throwError "Missing top-level solution"
  unless info.isTheorem do throwError "solution must be a theorem"
  if env.isImportedConst `solution then throwError "solution must be local"
  let forbidden : String := "Theorems.Thm_CompetingChains_Cournot_proposition_7a"
  for moduleName in env.header.moduleNames do
    if moduleName.toString == forbidden then throwError "Circular target import"
  let allowed : Array Lean.Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let localDecls := env.constants.foldStage2 (fun xs n c => xs.push (n, c)) #[]
  for (name, decl) in localDecls do
    if !env.isImportedConst name then
      if decl.isAxiom then throwError "Local axiom is forbidden: {name}"
      for axiomName in (← Lean.collectAxioms name) do
        unless allowed.contains axiomName do
          throwError "Unexpected axiom in local declaration: {axiomName}"
  let axioms ← Lean.collectAxioms `solution
  for axiomName in axioms do
    unless allowed.contains axiomName do
      throwError "Unexpected axiom in solution: {axiomName}"
  let data := Lean.Json.arr (axioms.map fun n => Lean.Json.str n.toString)
  IO.println ("PROOF_WORKFLOW_AXIOMS 0df69a996eac4b9abeeecb13de0a7582 " ++ data.compress)
