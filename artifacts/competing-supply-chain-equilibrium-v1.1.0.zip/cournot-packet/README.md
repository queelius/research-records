# Pure information-sharing equilibria in competing supply chains

Version 1.1.0 · [10.5281/zenodo.23527408](https://doi.org/10.5281/zenodo.23527408). Identifiers were reserved during assembly; the separate publication receipt establishes public availability. See NOTE.md for the exact contribution, assumptions, proof outline,
credit and limitations. This packet contains one complete accepted proof, both
platform definitions, immutable source pins and verification evidence. The
underlying theorem belongs to Ha, Tian and Tong (2017). The checked claim is the
explicit platform formulation; full source-paper inspection remains unavailable.

## Reproduce

On Linux/POSIX with Python 3.10+, Git and elan, from this directory:

```sh
python3 scripts/verify_archive.py --integrity-only
python3 scripts/verify_archive.py --setup
```

First setup needs network and several GB of disk. No platform credentials are
required. The verifier obtains Lean 4.33.1 and pinned Mathlib dependencies,
rebuilds both platform definitions and checks the complete target with
`autoImplicit=false`. Expected report: `status: passed`, one compiled target,
only `propext`, `Classical.choice`, `Quot.sound`. Compiled third-party caches are
trusted inputs. See verification/README.md for verified-cache reuse.

## Evidence and controls

Accepted proof and audit bytes are unchanged. Historical command/log filesystem
prefixes are normalized with original and normalized hashes recorded. No open
theorem placeholder is imported; target JSON may contain the platform's original
by-sorry statement as historical text. Controls intentionally change a proof
byte, weaken its statement, or add a local axiom; each must be rejected and none
was submitted. verification/receipt.json records actual results. MANIFEST.json
inventories every packet file except itself. See provenance.json, NOTICE.md,
LICENSE and CITATION.cff for credit, licensing and citation.

This is one archival version of an already accepted proof, not a new target or
mathematical novelty claim. Boundary cases and mixed strategies remain outside
its scope; formal checking is distinct from independent human proof review.
