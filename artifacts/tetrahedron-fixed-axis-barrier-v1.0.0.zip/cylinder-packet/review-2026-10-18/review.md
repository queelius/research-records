# Independent review of arbitrary positive radial profiles

Reviewed 2026-10-18 for Alexander Richard Towell's final bounded cylinder
investigation. This is a separate OpenAI Codex mathematical review, not
human peer review or a formal proof. Credit Ricardo Pinho for the fixed
axes, explicit construction, normalization and source certificate; credit
Towell's preceding shared-profile audit and independent-even-profile
extension, both with substantial AI assistance, for the inherited integral,
segment argument and endpoint estimate.

**Verdict:** no mathematical blocker found. The four physical orientations
give the asserted directed cycle without a hidden evenness assumption.
The injective compensation argument proves the four-term quadratic bound,
and pairing positive and negative angular integrals recovers exactly the
predecessor's full normalized cost bound. No proof correction is required
by this review.

This review concerns the new orbit/matching argument in `PROOF.md` and its
stated scope in `PLAN.md`. It relies on the inherited segment geometry and
finite coefficient estimate, which were independently checked in the
preceding review; the new tests also directly exercise those geometric
conditions with non-even profiles. The main agent remains responsible for
the production checker, unit/integration tests, and complete integral
replay. This reviewer did not rerun the full-cover certificate or inspect
unrelated research. No file in the preceding even-profile packet was edited.

## Mathematical findings

For a lower triangle, `J(x,y,t)=(-y,x,1-t)` maps the node vertex
`(0,q_j*A_j,A_j)` to `(-q_j*A_j,0,1-A_j)`. The destination is the upper
node `n-j`, carrying radius `A_j`, not `A_(n-j)`. Thus the destination
profile is `A^-`. An upper node vertex maps to a lower vertex at the same
node with the same `B_j`. Lower axes map to reflected upper axes; upper
axes map to negatives of lower axes in the original sector. Consequently
the actual transformation is exactly

```text
(A,B) -> (B,A^-) -> (A^-,B^-) -> (B^-,A) -> (A,B).
```

This uses the retained reflection symmetry of the fixed secant geometry,
not symmetry of either radius profile. The affine map preserves the
physical metric `diag(1,1,2)` and the tetrahedron. Its images are therefore
covers whenever the original family is a cover.

Reflection also commutes with inverse-radius interpolation. If
`q=q_j+h*(q_(j+1)-q_j)`, the reflected point is in sector `n-1-j` at
fraction `1-h`. Both ways of reflecting the cutoff give inverse radius
`(1-h)/A_(n-j)+h/A_(n-j-1)`. This identity holds for arbitrary positive
node values. A claim that reflection commuted with ordinary interpolation
of the radii would not suffice, but the proof uses the correct cutoff.

With `A+=A(q)`, `A-=A(-q)` and similarly for `B`, the directed segment
condition reads as follows:

| Orientation | Lower cutoff at `q` | Upper cutoff at `-q` | Cycle edge |
| --- | --- | --- | --- |
| Original | `A+` | `B-` | `z0 -> z1` |
| `J` | `B+` | `A+` | `z3 -> z0` |
| `J^2` | `A-` | `B+` | `z2 -> z3` |
| `J^3` | `B-` | `A-` | `z1 -> z2` |

Here `(z0,z1,z2,z3)=(A+,B-,A-,B+)`. This verifies the ordering in
the proof's equations (5) and (6); it is a cycle with four labeled
occurrences, even when some numerical cutoff values happen to coincide.

The segment's exclusion of every other angular sector remains applicable
to every orientation. Before obtaining `rho<=A(q) or sigma<=B(-q)`, its
proof uses the axes, tetrahedron inequalities and positive radial
interpolation, but no equality between values at `q` and `-q`. Each
image family has those same axes and satisfies the same geometric
hypotheses. Applying the original disjunction to these four families is
legitimate; replacing `B(-q)` by `B(q)` would not be.

For an edge `F(x,y)` with `x<T`, the original segment limits give two
complete cases. If `rho0<=x<T`, then
`y>=T+(alpha/beta)*(T-x)>=2T-x>T`, and the pair contributes at least
`2T^2`. If `x<rho0`, then `y>=sigma0>=3T/2>T`, again contributing more
than `2T^2`. Equality at `x=rho0` belongs to the first case. No ordering
between `x` and `y` is assumed in advance, so this lemma does not silently
reuse the earlier even-profile sorting step.

Pairing every index with value below `T` to its successor gives disjoint
pairs. Distinct small indices have distinct successors because this is a
permutation; every such successor is strictly above `T`, so it cannot be
another selected small index. Consequently there are at most two pairs.
Each pair contributes at least `2T^2`, and every unpaired occurrence
contributes at least `T^2`. This proves the sum of the four squares is at
least `4T^2`. Large radii are never counted twice. Covers are not averaged
or combined to establish this argument.

The area calculation does not assume even radii. Reflection changes the
secant pair `(a,b)` to `(a,-b)`, leaving the denominator
`sqrt(1+tau^2*(a^2+2*b^2))` unchanged. Therefore the original full cost is
exactly one half of the positive-half integral of
`A(q)^2+B(q)^2+A(-q)^2+B(-q)^2` with that denominator. The four-term
bound gives the factor `2` multiplying the inherited `T^2` integral.
Every original family and angular half is counted once; there is no
unpriced helper cover and no factor from summing the four image covers.

The argument proves the pointwise estimate for open positive-sector
angles. At `q=0` and every other node, separate one-sided limits suffice;
even if the one-sided secant formulas differ, both limits may be taken.
These finitely many angles have measure zero in the cost integral.
`tau=0` has `rho0=0`, so the small-cutoff case is empty for positive
radii; the remaining case still applies. At `tau=1`, `u<1` keeps all
required denominators positive and the segment nondegenerate. Neither tilt
endpoint requires a new limit argument.

## Independent exact controls

Run from this packet:

```sh
python independent_orbit_review.py
python -O independent_orbit_review.py
```

Both commands passed. The script uses only the standard library and exact
`Fraction` arithmetic, imports no production or predecessor checker, and
uses explicitly non-even positive node values

```text
A_j = 2/5 + q_j/17 + q_j^2/23
B_j = 3/4 - q_j/19 + q_j^3/29.
```

These profiles are transformation controls, not an asserted cover. The
script checks:

- 49,152 cylinder transformations: all sectors, both families, all four
  orientations, and tilts `0`, `1/2`, `1`, comparing exact triangle vertex
  sets and transformed axes;
- 2,048 interior-angle reflection/interpolation and directed-edge checks;
- 18 rational segment points, each tested against all 2,048 angular
  sectors in each family, with signed radial membership checked separately
  by triangle barycentric coordinates in all four profile orientations;
- 28,464 four-radius grid tuples, of which 5,154 satisfy every directed
  segment condition and pass the disjoint-pair and total-cost checks;
- all 1,024 reflected sector cost pairs, with four potentially unequal
  endpoint-radius products retained.

The scalar checker independently expresses failure of `F(x,y)` as the
nonempty open interval

```text
max(rho0,x) < rho < min(T,(1-beta*y)/alpha).
```

This directly tests simultaneous strict radial failures rather than
assuming the proof's compensation case split. Its grid tests supplement
the written argument for arbitrary positive real radii; they do not
replace that argument.

Meaningful negative controls also pass:

- Deleting any one of the four orbit edges permits its source radius to
  equal `T/10` while the other three equal `T`. Every retained edge holds,
  yet the total is `301*T^2/100<4T^2`. The missing edge has an explicit
  rational uncovered segment witness, and the full-cycle checker rejects
  the tuple.
- A noninjective successor graph can send three `T/10` radii to one
  `19*T/10` radius. Every small-to-large edge holds at zero tilt and every
  such pair separately contributes at least `2T^2`, but the actual total
  is only `91*T^2/25<4T^2`. This demonstrates why compensation cannot be
  reused.
- The even-only swap `(A,B)->(B,A)` differs from the exact transformed
  node profiles and is rejected by the non-even control.

These controls refute incomplete necessary-condition arguments. They are
not counterexamples to the theorem and do not certify a tetrahedron cover.
No finite probe here constitutes a formal proof or a complete coverage
certificate.

## Source and review pins

Accepted predecessor: `rpinho/tetrahedron-cylinder-cover` at
`ec5e88b8c954b8ce42ee71a993271e14dce1aded`. The independent-even extension
used here is pinned at `2bff558c3c6ed29dcda80730ef2c255ee58ac477`.
The preceding archived proof still has SHA-256
`f2020b8362b5e2ba785f2a110644bb0d9f378235b67469588afd0cc7ca45d8a4`.

The final proof calls the transformed covers "isometric images of the
cover", accounting for the reflection of `t` in `J`. Exact comparison
confirmed that this terminology adjustment was the only post-review proof
change. The final statement and argument remain as reviewed above.

| Reviewed artifact | SHA-256 |
| --- | --- |
| Current `PROOF.md` | `49c387c8c0562232813ee02bed084c82426a6a23a472c0af1aa566080ffd78cb` |
| Current `PLAN.md` | `f303df5d90ce5d27588b5eedc5c503c5af2e68c53bcd614a7d6cd15c891eb6f8` |
| `independent_orbit_review.py` | `3166bc8e99294982ffa511deabf5de40ad404bfc56b62ccded19043a8be7bc9a` |

The predecessor's exact coefficient and integration calculations remain
necessary components of the complete numerical theorem. This review
establishes that removing evenness still leads to that same integral;
the main run supplies its full replay evidence. Separate AI review is
distinct from external acceptance, human peer review and machine-checked
formal verification.
