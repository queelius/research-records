# Arbitrary node radii: final bounded cylinder investigation

Alexander Richard Towell, with substantial OpenAI Codex assistance.

Started 2026-10-18 07:12:36 UTC. Feasibility gate 07:27:36 UTC.
Verification/handoff reserved from 07:42:36 UTC. Hard stop 07:57:36 UTC.
Do not start another research cycle after this visit.

Archive base: bc2e7fb86b86643eb226f8841107947bd5d3f61c.
Accepted source: rpinho/tetrahedron-cylinder-cover at
ec5e88b8c954b8ce42ee71a993271e14dce1aded.
Existing PR #2 head: 2bff558c3c6ed29dcda80730ef2c255ee58ac477.
Archive branch: research/cylinder-arbitrary-radii-20261018.
Contribution branch: research/arbitrary-radii, based on that PR head.
The accepted shared-profile audit and completed independent-even-profile
packet remain unchanged in the archive.

## Proposition and significance

For n=2048, q_j=-1+2j/n, the fixed polynomial
phi(q)=(1-q^2)(1-q^2/200+27q^4/1250)/4, its secant axes, and
0<=tau<=1, allow independently chosen positive node radii A_j,B_j
without any evenness hypothesis. If the resulting two cylinder families
cover K={|x|<=1-t, |y|<=t}, must their total perpendicular-base area,
normalized by sqrt(2), satisfy C>=4993/10000?

This removes the remaining radial-symmetry restriction from the proposed
barrier, identifying whether asymmetric radii can evade it. It retains all
axis, tilt, sector, metric, base-shape and normalization assumptions.
It is not a proposed new cover or a bound for arbitrary cylinder covers.

## Method, complete budget, and success criterion

Reuse the proved segment exclusion without replacing B(-q) by B(q).
Derive the action of J(x,y,t)=(-y,x,1-t) on arbitrary profiles. Its four
orientations should impose directed constraints on A(q),B(-q),A(-q),B(q).
Test whether every subthreshold radius can be paired injectively with
its successor so that each pair contributes at least 2T^2.

The complete cost remains
C=(1/2) sum_j integral_(q_j)^(q_(j+1))
  (A(q)^2+B(q)^2)/sqrt(1+tau^2(a_j^2+2b_j^2)) dq,
where A and B are reciprocal-affine radial cutoffs. A four-term lower
bound of 4T^2 would recover exactly the earlier positive-half integral.
No averaging of covers or separate unpriced helper construction is used.

Success requires a written continuum proof, exact replay of all inherited
arithmetic, non-even transformation controls, controls rejecting an
incomplete orbit or double-counted compensation, and one scoped independent
AI review. Finite probes are not a formal proof. If the orbit implication
fails, record its exact failure and stop or make one evidence-driven pivot
within this same claim; a feasible relaxation is not a covering construction.

At the 15-minute gate stop if no concrete proof route is established.
No new explicit-cover certificate replay, broad survey or infrastructure
project. Finish investigation by the protected verification boundary.

## Overlap and publication

At 07:15 UTC the accepted main and PR #2 heads are unchanged. PR #2 is the
only open source issue/PR and has no comments or reviews. The latest issue55
claim is our completed independent-even visit; no arbitrary-profile claim
was observed. No CONTRIBUTING, AGENTS or PR template was found in the source
checkout; its MIT license is retained. Refresh again before publication.

If verified, update existing PR #2 with one focused fast-forward correction,
not a new PR. Preserve the original even-profile packet and exact source
pins. Credit Ricardo Pinho, the shared-profile audit and the even-profile
extension. Distinguish local verification, AI review and external acceptance.
