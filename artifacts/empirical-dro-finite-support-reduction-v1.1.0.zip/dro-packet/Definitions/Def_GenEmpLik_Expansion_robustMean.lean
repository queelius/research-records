import Mathlib
import Definitions.Def_PhiDivRobust_Counterpart_uncertaintySet

namespace GenEmpLik.Expansion

/-- The robust mean `sup { E_P[Z] : D_f(P ‖ P̂_n) ≤ ρ/n }` of the sample `z = (z₁, …, zₙ)`
(Duchi, Glynn & Namkoong, arXiv:1610.03425v3, p. 7, (8); the ball of (31)–(32), p. 32).
A distribution `P ≪ P̂_n` is a weight vector `p` on the sample, and
`D_f(P ‖ P̂_n) = ∑ᵢ (1/n) f(n pᵢ)` is the published `phiDiv f p (fun _ => 1/n)`, so the ball is the
published `probUncertaintySet f (fun _ => 1/n) (ρ/n) = {p ≥ 0 | ∑ pᵢ = 1, ∑ᵢ (1/n) f(n pᵢ) ≤ ρ/n}`.
For `0 < n` and `0 ≤ ρ` the set of values is non-empty (it contains the uniform vector, as
`f 1 = 0`) and bounded (it lies in the simplex), so the real `sSup` is the supremum. -/
noncomputable def robustMean {n : ℕ} (f : ℝ → EReal) (ρ : ℝ) (z : Fin n → ℝ) : ℝ :=
  sSup ((fun p : Fin n → ℝ => ∑ i, p i * z i) ''
    PhiDivRobust.Counterpart.probUncertaintySet f (fun _ => (1 : ℝ) / n) (ρ / n))

end GenEmpLik.Expansion
