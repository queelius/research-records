import Mathlib
import Definitions.Def_GenEmpLik_Expansion_robustMean

namespace EmpiricalDRO.Coverage

/-- The Burg generator `φ(t) = −log t + t − 1` (Lam, arXiv:1605.09349v1, p. 6), valued in `EReal`.
For `t ≤ 0` it is `⊤`: the paper's convention `log 0 = −∞` gives a zero weight infinite divergence.
With this generator and reference weights `1/n`, the published
`PhiDivRobust.Counterpart.probUncertaintySet burg (fun _ => 1/n) η` is the empirical Burg ball
`U_n(η) = {w : −(1/n) ∑ log(n wᵢ) ≤ η, ∑ wᵢ = 1, w ≥ 0}` of (19), p. 8. -/
noncomputable def burg (t : ℝ) : EReal :=
  if 0 < t then ((-Real.log t + t - 1 : ℝ) : EReal) else ⊤

/-- The lower robust value `inf { ∑ pᵢ zᵢ : p ∈ U_n(ρ/n) }` of the sample `z = (z₁, …, zₙ)` over the
empirical divergence ball with generator `f` and radius `ρ/n`, the `sInf` twin of the published
`GenEmpLik.Expansion.robustMean`. With `f = burg` and `ρ = χ²_{1,1−α}/2` it is `Z_n(x)` of (26),
p. 11. When `f = burg`, `0 < n`, and `0 ≤ ρ`, the value set is nonempty (it contains the
uniform vector) and bounded (it lies in the simplex), so the real `sInf` is the minimum. -/
noncomputable def robustLower {n : ℕ} (f : ℝ → EReal) (ρ : ℝ) (z : Fin n → ℝ) : ℝ :=
  sInf ((fun p : Fin n → ℝ => ∑ i, p i * z i) ''
    PhiDivRobust.Counterpart.probUncertaintySet f (fun _ => (1 : ℝ) / n) (ρ / n))

/-- The empirical-likelihood statistic `−2 log R(μ)` of the sample `z = (z₁, …, zₙ)` at the value `μ`
((22), p. 10, and (24), p. 11):
`inf { −2 ∑ log(n wᵢ) : wᵢ > 0, ∑ wᵢ = 1, ∑ wᵢ zᵢ = μ }`, valued in `EReal`.
The infimum of the empty family is `⊤`, the paper's "defined as ∞ if there is no feasible solution".
Weights are strictly positive: with `log 0 = −∞` a zero weight makes `∏ (n wᵢ) = 0`, which never
improves the maximum in (22), and gives `−2 log R = ∞` when every feasible weight has a zero. -/
noncomputable def elStat {n : ℕ} (z : Fin n → ℝ) (μ : ℝ) : EReal :=
  ⨅ (w : Fin n → ℝ) (_ : (∀ i, 0 < w i) ∧ ∑ i, w i = 1 ∧ ∑ i, w i * z i = μ),
    ((-2 * ∑ i, Real.log (n * w i) : ℝ) : EReal)

end EmpiricalDRO.Coverage
