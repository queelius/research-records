import Mathlib
import Definitions.Def_GenEmpLik_Expansion_robustMean
import Definitions.Def_EmpiricalDRO_Coverage_Setting

namespace EmpiricalDRO.Discrete

/-- The number of sample observations equal to support point `i` (p. 6). -/
def count {n k : ℕ} (c : Fin n → Fin k) (i : Fin k) : ℕ :=
  (Finset.univ.filter fun j => c j = i).card

/-- The empirical histogram, with mass `nᵢ/n` on support point `i` (p. 6). -/
noncomputable def phat {n k : ℕ} (c : Fin n → Fin k) (i : Fin k) : ℝ :=
  (count c i : ℝ) / n

/-- The finite-support Burg ball of (28), interpreted in the absolutely continuous class
`P_{p̂}` specified in (13)–(14). A positive baseline coordinate must also have positive
candidate mass, so the logarithm has its intended extended-real meaning. -/
def burgBall {k : ℕ} (phat : Fin k → ℝ) (η : ℝ) : Set (Fin k → ℝ) :=
  {p | (∀ i, 0 ≤ p i) ∧
    ∑ i, p i = 1 ∧
    (∀ i, phat i = 0 → p i = 0) ∧
    (∀ i, 0 < phat i → 0 < p i) ∧
    -∑ i, phat i * Real.log (p i / phat i) ≤ η}

end EmpiricalDRO.Discrete
