# Finite-support empirical DRO reduction

Version 1.1.0 · [10.5281/zenodo.23527418](https://doi.org/10.5281/zenodo.23527418). Identifiers were reserved during assembly; the separate publication receipt establishes public availability. This standalone archive contains three accepted proofs of Henry
Lam's established finite-support reduction: aggregation, equal splitting, and
equality of the lower and upper robust values. See NOTE.md for assumptions and
scope, record.json for exact targets and credit, and provenance.json for pins.
No asymptotic coverage or mathematical novelty is claimed.

## Reproduce

On Linux/POSIX with Python 3.10+, Git and elan, from this directory:

```sh
python3 scripts/verify_archive.py --integrity-only
python3 scripts/verify_archive.py --setup
```

First setup needs network and several GB of disk; no platform credentials are
required. The verifier obtains Lean 4.33.1 and immutable Mathlib/transitive pins,
rebuilds all five platform definitions and audits each complete target with
`autoImplicit=false`. Expected: `status: passed`, three compiled targets and
only `propext`, `Classical.choice`, `Quot.sound`. Pinned compiled caches remain
trusted inputs; this is not a Lean/Mathlib bootstrap check. See
verification/README.md for explicit cache reuse.

## Evidence and citation

Accepted proofs and independent audits retain their exact bytes. The full root
proof includes both feasible-weight directions without open theorem imports.
Historical log and command prefixes are normalized with original and portable
hashes retained. Target JSON may retain the platform's by-sorry statement as
historical text; compiled solutions contain no such placeholder.

The three controls are deliberately invalid and must be rejected: altered proof
bytes, weaker target and extra local axiom. They were never submitted.
verification/receipt.json records fresh evidence; MANIFEST.json inventories all
packet files except itself. Cite CITATION.cff for this exact version and cite
Lam for the mathematics. NOTICE.md and LICENSE preserve predecessor,
platform and Lean/Mathlib credit and disclose substantial Codex assistance.
Original public submissions, platform acceptance, reproduction and DOI archival
publication are separate events. Independent human review is not claimed.
