#!/usr/bin/env python3
"""Reproduce the archived contributions without credentials or platform writes.

Python 3.10+; compilation additionally needs the pinned Lean toolchain and cache.
All accepted bytes and historical evidence are read-only. Each invocation creates
its own snapshot, compiler outputs, logs, and JSON report under --work-dir.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile
import time
from typing import Any


class ArchiveError(Exception):
    """An archive or reproduction invariant did not hold."""


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ArchiveError(message)


def json_object(data: bytes, label: str) -> dict[str, Any]:
    try:
        value = json.loads(data)
    except (ValueError, UnicodeError) as exc:
        raise ArchiveError(f"Invalid JSON in {label}: {exc}") from exc
    require(isinstance(value, dict), f"Expected JSON object in {label}")
    return value


def relative_path(root: Path, value: str) -> Path:
    require(isinstance(value, str) and bool(value), "Missing relative path")
    path = PurePosixPath(value)
    require(not path.is_absolute() and ".." not in path.parts and "\\" not in value,
            f"Unsafe archive path: {value}")
    result = (root / path).resolve()
    require(result.is_relative_to(root.resolve()), f"Archive path escapes its root: {value}")
    return result


def read_file(path: Path) -> bytes:
    require(path.is_file(), f"Missing source/evidence file: {path}")
    return path.read_bytes()


def checked_file(root: Path, record: dict[str, Any]) -> tuple[str, bytes]:
    name = record["path"]
    data = read_file(relative_path(root, name))
    require(digest(data) == record["sha256"], f"SHA256 hash mismatch: {name}")
    return name, data


def is_hex(value: Any, length: int) -> bool:
    return (isinstance(value, str) and len(value) == length
            and all(c in "0123456789abcdef" for c in value))


@dataclass(frozen=True)
class Target:
    theorem_id: str
    proof_path: str
    proof: bytes
    audit_path: str
    audit: bytes
    evidence_path: str
    evidence: bytes

    def record(self) -> dict[str, Any]:
        return {"theorem_id": self.theorem_id, "proof_file": self.proof_path,
                "proof_sha256": digest(self.proof), "audit_file": self.audit_path,
                "audit_sha256": digest(self.audit), "evidence_file": self.evidence_path,
                "evidence_sha256": digest(self.evidence), "compiled": False}


@dataclass(frozen=True)
class Archive:
    root: Path
    environment: dict[str, Any]
    setup_files: dict[str, bytes]
    packages: list[dict[str, Any]]
    sources: dict[str, bytes]
    targets: list[Target]


def load_archive(root: Path, environment_path: str) -> Archive:
    env = json_object(read_file(relative_path(root, environment_path)), environment_path)
    require(env["schema_version"] == 1, "Unsupported environment schema")
    version = env["lean_version"]
    require(isinstance(version, str) and len(version.split(".")) == 3
            and all(part.isdigit() for part in version.split(".")), "Invalid Lean version pin")
    require(is_hex(env["mathlib_rev"], 40), "Invalid Mathlib revision pin")
    require(isinstance(env["allowed_axioms"], list)
            and all(isinstance(x, str) for x in env["allowed_axioms"]), "Invalid allowed axioms")
    setup = {name: checked_file(root, record)[1] for name, record in env["setup_files"].items()}
    require(set(setup) == {"lean-toolchain", "lakefile.lean", "lake-manifest.json"},
            "Environment must pin all three setup files")
    require(setup["lean-toolchain"].decode().strip() == f"leanprover/lean4:v{version}",
            "Toolchain file disagrees with Lean pin")
    manifest = json_object(setup["lake-manifest.json"], "lake-manifest.json")
    require(manifest["packagesDir"] == ".lake/packages", "Unsafe pinned packages path")
    packages = manifest["packages"]
    require(isinstance(packages, list), "Invalid dependency manifest")
    names: set[str] = set()
    for package in packages:
        name = package["name"]
        require(isinstance(name, str) and name and Path(name).name == name
                and name not in {".", ".."} and "\\" not in name,
                f"Unsafe package path: {name}")
        require(name not in names, f"Duplicate dependency package: {name}")
        names.add(name)
        require(package["type"] == "git" and is_hex(package["rev"], 40),
                f"Invalid immutable dependency pin: {name}")
        require(package.get("subDir") is None, f"Unsupported package subDir: {name}")
        require(isinstance(package["url"], str) and package["url"].startswith("https://"),
                f"Dependency URL must use HTTPS: {name}")
    require(any(p["name"] == "mathlib" and p["rev"] == env["mathlib_rev"] for p in packages),
            "Dependency manifest disagrees with Mathlib pin")
    module_roots = env["module_roots"]
    require(isinstance(module_roots, list) and module_roots, "Missing platform module roots")
    for name in module_roots:
        require(relative_path(root, name).parent == root.resolve(), "Invalid module root path")
    source_manifest = json_object(read_file(relative_path(root, env["platform_manifest"])),
                                  env["platform_manifest"])
    require(source_manifest["schema_version"] == 1, "Unsupported platform source schema")
    sources: dict[str, bytes] = {}
    for record in source_manifest["sources"]:
        name, data = checked_file(root, record)
        require(PurePosixPath(name).parts[0] in module_roots and name.endswith(".lean"),
                f"Source outside platform module roots: {name}")
        require(name not in sources, f"Duplicate platform source: {name}")
        sources[name] = data
    actual_sources = {p.relative_to(root).as_posix()
                      for name in module_roots for p in (root / name).rglob("*.lean")}
    require(actual_sources == set(sources), "Platform source manifest differs from module roots")

    base = relative_path(root, "contributions/queelius")
    ledger = json_object(read_file(base / "contributions.json"), "contributions.json")
    require(ledger["schema_version"] == 1, "Unsupported contribution ledger schema")
    require(isinstance(ledger["entries"], list) and ledger["entries"], "Empty contribution ledger")
    targets = []
    ids: set[str] = set()
    for entry in ledger["entries"]:
        target_id = entry["theorem_id"]
        require(isinstance(target_id, str) and target_id, "Missing theorem ID")
        require(target_id not in ids, f"Duplicate target: {target_id}")
        ids.add(target_id)
        require(entry["verdict"] == "ACCEPTED", f"Target is not a completed accepted result: {target_id}")
        require(entry["mathlib_rev"] == env["mathlib_rev"], f"Target environment pin mismatch: {target_id}")
        proof_name, proof = checked_file(base, {"path": entry["proof_file"], "sha256": entry["proof_sha256"]})
        evidence_path = relative_path(base, entry["evidence_file"])
        evidence_bytes = read_file(evidence_path)
        evidence = json_object(evidence_bytes, entry["evidence_file"])
        require(evidence["schema_version"] == 1, "Unsupported evidence schema")
        target = evidence["target"]
        require(target["theorem_id"] == target_id and target["theorem_name"] == entry["theorem_name"],
                f"Evidence target mismatch: {target_id}")
        require(target["mathlib_rev"] == env["mathlib_rev"], f"Evidence environment pin mismatch: {target_id}")
        accepted = {s["id"] for s in evidence["submissions"]
                    if s["theorem_id"] == target_id and s["status"] == "ACCEPTED"}
        require(entry["primary_submission_id"] in accepted
                and set(entry["accepted_submission_ids"]).issubset(accepted),
                f"Missing accepted submission receipt: {target_id}")
        check = evidence["local_recheck"]
        require(check["proof_file"] == proof_name and check["proof_sha256"] == digest(proof),
                f"Evidence proof path/hash mismatch: {target_id}")
        require(check["mathlib_rev"] == env["mathlib_rev"] and check["exit_code"] == 0,
                f"Invalid historical check environment or exit code: {target_id}")
        audit_name, audit = checked_file(base, {"path": check["audit_file"], "sha256": check["audit_sha256"]})
        checked_file(base, {"path": check["log_file"], "sha256": check["log_sha256"]})
        require(audit.startswith(proof) and len(audit) > len(proof)
                and check["proof_is_exact_prefix_of_audit"] is True,
                f"Audit does not contain exact proof byte prefix: {target_id}")
        require(set(check["axioms"]).issubset(env["allowed_axioms"]), f"Untrusted historical axioms: {target_id}")
        prefix = "contributions/queelius/"
        targets.append(Target(target_id, prefix + proof_name, proof, prefix + audit_name,
                              audit, prefix + entry["evidence_file"], evidence_bytes))
    return Archive(root, env, setup, packages, sources, targets)


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".report-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class Commands:
    """Subprocess execution with retained command, output hash, and exit status."""

    def __init__(self, run: Path, report: dict[str, Any]):
        self.run = run
        self.report = report

    def execute(self, argv: list[str | Path], cwd: Path,
                env: dict[str, str] | None = None) -> str:
        command = [str(arg) for arg in argv]
        start = time.monotonic()
        result = subprocess.run(command, cwd=cwd, env=env, capture_output=True)
        log = self.run / "logs" / f"{len(self.report['commands']):04d}.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        output = result.stdout + result.stderr
        log.write_bytes(output)
        self.report["commands"].append({"argv": command, "cwd": str(cwd),
                                        "exit_code": result.returncode,
                                        "duration_seconds": round(time.monotonic() - start, 3),
                                        "log_file": str(log), "log_sha256": digest(output)})
        require(result.returncode == 0, f"Command failed with exit {result.returncode}; see {log}")
        return result.stdout.decode("utf-8")


def freeze(archive: Archive, run: Path) -> dict[str, bytes]:
    files = dict(archive.sources)
    for target in archive.targets:
        files[target.proof_path] = target.proof
        files[target.audit_path] = target.audit
        files[target.evidence_path] = target.evidence
    for name, data in files.items():
        path = run / "snapshot" / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        path.chmod(0o444)
    return files


def parsed_imports(compiler: Path, paths: list[Path], commands: Commands,
                   env: dict[str, str]) -> dict[str, list[str]]:
    helper = Path(__file__).resolve().parents[1] / "verification/Imports.lean"
    output = commands.execute([compiler, "--run", helper, *paths], commands.run, env)
    rows = json.loads(output)
    require(isinstance(rows, list) and len(rows) == len(paths), "Invalid Lean import parser response")
    result = {}
    for row in rows:
        require(isinstance(row, dict) and isinstance(row["path"], str)
                and isinstance(row["imports"], list)
                and all(isinstance(name, str) for name in row["imports"]),
                "Invalid structured imports")
        require(row["path"] not in result, "Duplicate Lean import parser response")
        result[row["path"]] = row["imports"]
    require(set(result) == {str(p) for p in paths}, "Lean import parser returned unexpected paths")
    return result


def dependency_order(archive: Archive, snapshot: Path,
                     imports: dict[str, list[str]]) -> tuple[list[str], list[str]]:
    modules = {".".join(PurePosixPath(name).with_suffix("").parts): name
               for name in archive.sources}
    roots = set(archive.environment["module_roots"])
    seen: set[str] = set()
    active: set[str] = set()
    external: set[str] = set()
    order = []

    def visit(module: str) -> None:
        if module in seen:
            return
        if module not in modules:
            require(module.split(".")[0] not in roots, f"Missing platform dependency source: {module}")
            external.add(module)
            return
        require(module not in active, f"Platform dependency cycle involving {module}")
        active.add(module)
        for dependency in imports[str(snapshot / modules[module])]:
            visit(dependency)
        active.remove(module)
        seen.add(module)
        order.append(module)

    for target in archive.targets:
        for dependency in imports[str(snapshot / target.audit_path)]:
            visit(dependency)
    return order, sorted(external)


def check_packages(archive: Archive, mathlib: Path, commands: Commands) -> None:
    checked = []
    for package in archive.packages:
        path = mathlib if package["name"] == "mathlib" else mathlib.parent / package["name"]
        require(path.is_dir(), f"Missing pinned dependency checkout: {path}")
        revision = commands.execute(["git", "-C", path, "rev-parse", "HEAD"], commands.run).strip()
        require(revision == package["rev"], f"Dependency revision pin mismatch: {package['name']}")
        checked.append({"name": package["name"], "rev": revision, "path": str(path)})
    commands.report["dependency_revisions"] = checked


def compiler_environment(archive: Archive, compiler: Path, mathlib: Path,
                         caches: list[Path], output: Path, commands: Commands) -> dict[str, str]:
    version = commands.execute([compiler, "--short-version"], commands.run).strip()
    require(version == archive.environment["lean_version"], f"Lean compiler version pin mismatch: {version}")
    commands.report["compiler_version"] = commands.execute([compiler, "--version"], commands.run).strip()
    check_packages(archive, mathlib, commands)
    require(bool(caches), "At least one explicit compiled dependency cache path is required")
    for cache in caches:
        require(cache.is_dir(), f"Missing compiled dependency cache path: {cache}")
        for root in archive.environment["module_roots"]:
            require(not (cache / root).exists(), f"External cache contains old platform modules: {cache / root}")
    output.mkdir(parents=True, exist_ok=True)
    paths = [output, *caches]
    commands.report["lean_path"] = [str(p) for p in paths]
    return {**os.environ, "LEAN_PATH": os.pathsep.join(str(p) for p in paths)}


def axiom_guard(allowed: list[str]) -> bytes:
    names = ", ".join(f"({json.dumps(name)}.toName)" for name in allowed)
    return ("\n-- Fresh transitive axiom guard added by the archive verifier.\n"
            "run_cmd do\n"
            f"  let allowed : Array Lean.Name := #[{names}]\n"
            "  let axioms ← Lean.collectAxioms `solution\n"
            "  for axiomName in axioms do\n"
            "    unless allowed.contains axiomName do\n"
            "      throwError \"Unexpected axiom in solution: {axiomName}\"\n"
            "  let data := Lean.Json.arr (axioms.map fun n => Lean.Json.str n.toString)\n"
            "  IO.println (\"ARCHIVE_AXIOMS_JSON \" ++ data.compress)\n").encode("utf-8")


def compile_archive(archive: Archive, run: Path, compiler: Path, mathlib: Path,
                    caches: list[Path], commands: Commands) -> None:
    frozen = freeze(archive, run)
    snapshot = run / "snapshot"
    output = run / "lib"
    env = compiler_environment(archive, compiler, mathlib, caches, output, commands)
    paths = [snapshot / name for name in archive.sources]
    paths.extend(snapshot / target.audit_path for target in archive.targets)
    imports = parsed_imports(compiler, paths, commands, env)
    order, external = dependency_order(archive, snapshot, imports)
    commands.report["imports"] = {str(Path(path).relative_to(snapshot)): deps for path, deps in imports.items()}
    commands.report["external_imports"] = external
    commands.report["compiled_modules"] = []
    for module in order:
        relative = Path(*module.split("."))
        olean = (output / relative).with_suffix(".olean")
        olean.parent.mkdir(parents=True, exist_ok=True)
        commands.execute([compiler, "-DautoImplicit=false", "-o", olean,
                          (snapshot / relative).with_suffix(".lean")], snapshot, env)
        require(olean.is_file(), f"Compiler did not create platform output: {module}")
        commands.report["compiled_modules"].append(module)
    for target, record in zip(archive.targets, commands.report["targets"]):
        # Compile a separate extended copy; both accepted source and original audit
        # remain byte-for-byte frozen, including CRLF line endings.
        # Different research packets may each contain an audit.lean. Preserve
        # the validated relative path so their immutable outputs cannot collide.
        audit = run / "checks" / target.audit_path
        audit.parent.mkdir(parents=True, exist_ok=True)
        audit_bytes = target.audit + axiom_guard(archive.environment["allowed_axioms"])
        audit.write_bytes(audit_bytes)
        audit.chmod(0o444)
        result = commands.execute([compiler, "-DautoImplicit=false", audit], snapshot, env)
        marker = "ARCHIVE_AXIOMS_JSON "
        rows = [json.loads(line[len(marker):]) for line in result.splitlines() if line.startswith(marker)]
        require(len(rows) == 1 and isinstance(rows[0], list)
                and all(isinstance(n, str) for n in rows[0]), f"Missing or ambiguous axiom check: {target.theorem_id}")
        require(set(rows[0]).issubset(archive.environment["allowed_axioms"]), f"Untrusted axioms: {target.theorem_id}")
        require(audit.read_bytes() == audit_bytes, f"Compiled audit changed during compilation: {target.theorem_id}")
        record.update({"compiled": True, "axioms": rows[0], "compiled_audit_sha256": digest(audit_bytes),
                       "compiled_audit_file": str(audit), "command_index": len(commands.report["commands"]) - 1})
    for name, data in frozen.items():
        require(read_file(snapshot / name) == data, f"Frozen source changed during compilation: {name}")
        require(read_file(relative_path(archive.root, name)) == data, f"Original source changed during compilation: {name}")


def setup_environment(archive: Archive, work: Path, commands: Commands) -> tuple[Path, Path, list[Path]]:
    """Install a pinned environment; never run lake update or build Mathlib sources.

    Only the small cache downloader executable may be built by Lake. The imported
    Mathlib closure is downloaded as precompiled artifacts from its pinned cache.
    A POSIX lock protects reuse of this one setup directory by local invocations.
    """
    setup = work / "environment"
    setup.mkdir(parents=True, exist_ok=True)
    with (work / "environment.lock").open("a+b") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        for name, data in archive.setup_files.items():
            path = setup / name
            if path.exists():
                require(path.read_bytes() == data, f"Existing setup pin file differs/changed: {path}")
            else:
                path.write_bytes(data)
        clean_env = {**os.environ, "LEAN_PATH": "", "MATHLIB_CACHE_DIR": str(work / "cache-downloads")}
        toolchain = archive.setup_files["lean-toolchain"].decode().strip()
        installed = commands.execute(["elan", "toolchain", "list"], setup, clean_env)
        if toolchain not in {line.split()[0] for line in installed.splitlines() if line.strip()}:
            commands.execute(["elan", "toolchain", "install", toolchain], setup, clean_env)
        compiler = Path(commands.execute(["elan", "which", "lean"], setup, clean_env).strip())
        lake = Path(commands.execute(["elan", "which", "lake"], setup, clean_env).strip())
        packages = setup / ".lake/packages"
        packages.mkdir(parents=True, exist_ok=True)
        for package in archive.packages:
            path = packages / package["name"]
            if not path.exists():
                path.mkdir()
                commands.execute(["git", "init", "--quiet", path], setup, clean_env)
                commands.execute(["git", "-C", path, "remote", "add", "origin", package["url"]], setup, clean_env)
                commands.execute(["git", "-C", path, "fetch", "--depth", "1", "origin", package["rev"]], setup, clean_env)
                commands.execute(["git", "-C", path, "checkout", "--detach", "FETCH_HEAD"], setup, clean_env)
            revision = commands.execute(["git", "-C", path, "rev-parse", "HEAD"], setup, clean_env).strip()
            require(revision == package["rev"], f"Fetched dependency pin mismatch: {package['name']}")
        paths = [archive.root / name for name in archive.sources]
        paths.extend(archive.root / target.audit_path for target in archive.targets)
        imports = parsed_imports(compiler, paths, commands, clean_env)
        mathlib_imports = sorted({module for dependencies in imports.values() for module in dependencies
                                 if module == "Mathlib" or module.startswith("Mathlib.")})
        require(bool(mathlib_imports), "No Mathlib imports found for targeted cache download")
        commands.execute([lake, "exe", "cache", "get", *mathlib_imports], setup, clean_env)
        # Lake may read the manifest but must never replace a pin behind our back.
        for name, data in archive.setup_files.items():
            require((setup / name).read_bytes() == data, f"Setup changed pinned file: {name}")
        mathlib = packages / "mathlib"
        caches = [packages / package["name"] / ".lake/build/lib/lean" for package in archive.packages
                  if (packages / package["name"] / ".lake/build/lib/lean").is_dir()]
        require(bool(caches), "Pinned cache downloader produced no compiled dependency directories")
        atomic_json(setup / "ready.json", {"schema_version": 1, "compiler": str(compiler),
                                           "mathlib": str(mathlib), "cache_dirs": [str(p) for p in caches],
                                           "manifest_sha256": digest(archive.setup_files["lake-manifest.json"])})
        return compiler, mathlib, caches


def ready_environment(archive: Archive, work: Path) -> tuple[Path, Path, list[Path]]:
    ready = work / "environment/ready.json"
    require(ready.is_file(), "Use --setup once for a fresh environment, or provide --compiler, --mathlib, --cache-dir")
    data = json_object(ready.read_bytes(), str(ready))
    require(data["schema_version"] == 1 and data["manifest_sha256"] == digest(archive.setup_files["lake-manifest.json"]),
            "Stored environment dependency manifest pin mismatch")
    return Path(data["compiler"]), Path(data["mathlib"]), [Path(p) for p in data["cache_dirs"]]


def argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1], help="Archive checkout root")
    parser.add_argument("--environment", default="verification/environments/lean-4.33.1.json", help="Environment manifest relative to root")
    parser.add_argument("--integrity-only", action="store_true", help="Check hashes, pins and receipts without running Lean")
    parser.add_argument("--setup", action="store_true", help="Fetch pinned source dependencies and their precompiled cache in work-dir")
    parser.add_argument("--compiler", type=Path, help="Explicit external Lean executable (requires --mathlib and --cache-dir)")
    parser.add_argument("--mathlib", type=Path, help="Explicit external pinned Mathlib git checkout")
    parser.add_argument("--cache-dir", type=Path, action="append", default=[], help="External compiled dependency root; repeat for all transitive packages")
    parser.add_argument("--work-dir", type=Path, help="Output/setup directory (default: root/.local/archive-verification)")
    parser.add_argument("--report", type=Path, help="JSON report destination (default: unique run directory/report.json)")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = argument_parser().parse_args(argv)
    root = args.root.resolve()
    work = (args.work_dir or root / ".local/archive-verification").resolve()
    work.mkdir(parents=True, exist_ok=True)
    run = Path(tempfile.mkdtemp(prefix="run-", dir=work))
    report_path = (args.report or run / "report.json").resolve()
    report: dict[str, Any] = {"schema_version": 1, "started_at": datetime.now(timezone.utc).isoformat(),
                              "mode": "integrity-only" if args.integrity_only else "compile",
                              "status": "failed", "run_directory": str(run), "commands": []}
    code = 1
    try:
        requested_report = report_path
        # Redirect failures to the run directory before checking a destination;
        # even a mistaken --report must never replace a source or a receipt.
        report_path = run / "report.json"
        require(requested_report.suffix == ".json", "Report destination would overwrite a non-JSON artifact")
        if requested_report.exists():
            existing = json_object(requested_report.read_bytes(), str(requested_report))
            require(existing.get("schema_version") == 1
                    and existing.get("mode") in {"integrity-only", "compile"}
                    and existing.get("status") in {"passed", "failed"}
                    and isinstance(existing.get("commands"), list),
                    "Report destination would overwrite an existing non-report artifact")
        report_path = requested_report
        archive = load_archive(root, args.environment)
        report["environment"] = archive.environment
        report["targets"] = [target.record() for target in archive.targets]
        report["platform_sources"] = [{"path": name, "sha256": digest(data)}
                                       for name, data in archive.sources.items()]
        if not args.integrity_only:
            commands = Commands(run, report)
            external = args.compiler is not None or args.mathlib is not None or bool(args.cache_dir)
            require(not (args.setup and external), "Cannot combine --setup with explicit external compiler/cache overrides")
            if args.setup:
                compiler, mathlib, caches = setup_environment(archive, work, commands)
            elif external:
                require(args.compiler is not None and args.mathlib is not None and bool(args.cache_dir),
                        "External reuse requires --compiler, --mathlib, and --cache-dir")
                compiler, mathlib, caches = (args.compiler.resolve(), args.mathlib.resolve(),
                                            [path.resolve() for path in args.cache_dir])
            else:
                compiler, mathlib, caches = ready_environment(archive, work)
            compile_archive(archive, run, compiler, mathlib, caches, commands)
        report["status"] = "passed"
        code = 0
    except (ArchiveError, OSError, KeyError, TypeError, ValueError) as exc:
        report["error"] = str(exc)
        print(f"Archive verification failed: {exc}", file=sys.stderr)
    finally:
        report["finished_at"] = datetime.now(timezone.utc).isoformat()
        atomic_json(report_path, report)
    print(f"{report['status']}: {report_path}")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
