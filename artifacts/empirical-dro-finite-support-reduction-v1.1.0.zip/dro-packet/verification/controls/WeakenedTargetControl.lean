import Mathlib
import Definitions.Def_EmpiricalDRO_Discrete_Setting
set_option autoImplicit false
theorem solution : True := by trivial

namespace EmpiricalDRO.Discrete

/-- Proof of Proposition 1, p. 24: aggregate observation weights by support point;
Jensen's inequality gives feasibility and the objective value is preserved. -/
theorem exact_target {n k : ℕ} (hn : 0 < n) (c : Fin n → Fin k)
    (a : Fin k → ℝ) (η : ℝ) (w : Fin n → ℝ)
    (hw : w ∈ PhiDivRobust.Counterpart.probUncertaintySet EmpiricalDRO.Coverage.burg
      (fun _ => (1 : ℝ) / n) η) :
    let p : Fin k → ℝ := fun i =>
      ∑ j ∈ Finset.univ.filter (fun j => c j = i), w j
    p ∈ burgBall (phat c) η ∧
    ∑ i, p i * a i = ∑ j, w j * a (c j) := solution hn c a η w hw

end EmpiricalDRO.Discrete

#print axioms EmpiricalDRO.Discrete.exact_target


-- Generated proof_workflow guard; keep the independent audit above.
run_cmd do
  let env ← Lean.getEnv
  let some info := env.find? `solution | throwError "Missing top-level solution"
  unless info.isTheorem do throwError "solution must be a theorem"
  if env.isImportedConst `solution then throwError "solution must be local"
  let forbidden : String := "Theorems.Thm_EmpiricalDRO_Discrete_w_to_p_feasible"
  for moduleName in env.header.moduleNames do
    if moduleName.toString == forbidden then throwError "Circular target import"
  let allowed : Array Lean.Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let localDecls := env.constants.foldStage2 (fun xs n c => xs.push (n, c)) #[]
  for (name, decl) in localDecls do
    if !env.isImportedConst name then
      if decl.isAxiom then throwError "Local axiom is forbidden: {name}"
      for axiomName in (← Lean.collectAxioms name) do
        unless allowed.contains axiomName do
          throwError "Unexpected axiom in local declaration: {axiomName}"
  let axioms ← Lean.collectAxioms `solution
  for axiomName in axioms do
    unless allowed.contains axiomName do
      throwError "Unexpected axiom in solution: {axiomName}"
  let data := Lean.Json.arr (axioms.map fun n => Lean.Json.str n.toString)
  IO.println ("PROOF_WORKFLOW_AXIOMS b1722292df4c4fd28d01c0ebdf085887 " ++ data.compress)
