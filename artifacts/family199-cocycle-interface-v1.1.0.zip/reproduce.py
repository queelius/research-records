"""Reproduce both source-pinned components of this Family199 archive."""
from pathlib import Path
import subprocess
import sys
base = Path(__file__).resolve().parent
for packet in ("cocycle", "homotopy"):
    subprocess.run([sys.executable, str(base / "source" / packet / "reproduce.py")], check=True)
print("RESULT: Family199 finite interface and explicit homotopy archive reproduced")
