import Mathlib
import Definitions.Def_MitigateSupplyRisk_DualSourcing_Model

namespace MitigateSupplyRisk.DualSourcing

namespace Model

/-- Generalized inverse `G_i^{-1}(u)` of the capacity-loss distribution at reliability index `a`:
the least `t ≥ 0` with `G_i(t, a) ≥ u`. When `G_i(·, a)` is continuous and strictly increasing on
its support `[0, b_i]` with `G_i(b_i, a) = 1`, this is the ordinary inverse on `(0, 1]`. -/
noncomputable def Ginv (M : Model) (i : Fin 2) (a u : ℝ) : ℝ :=
  sInf {t : ℝ | 0 ≤ t ∧ u ≤ M.G i t a}

/-- `A₁ = G₁^{-1}(φ₂)` at the reliability indices `a` (Theorem 2). -/
noncomputable def A1 (M : Model) (a : Fin 2 → ℝ) : ℝ := M.Ginv 0 (a 0) (M.phi 1)

/-- `A₂ = G₂^{-1}(φ₁)` at the reliability indices `a` (Theorem 2). -/
noncomputable def A2 (M : Model) (a : Fin 2 → ℝ) : ℝ := M.Ginv 1 (a 1) (M.phi 0)

/-- `B = G₁^{-1}((φ₂/φ₁) G₂(K₂))` at the reliability indices `a`, the quantity in the upper end
`K₁ − B` of the single-sourcing region `Ω₁` of Theorem 2, in its printed form. -/
noncomputable def B (M : Model) (a : Fin 2 → ℝ) : ℝ :=
  M.Ginv 0 (a 0) (M.phi 1 / M.phi 0 * M.G 1 (M.K 1) (a 1))

/-- The single-sourcing region `Ω₁ = {x : 0 ≤ x ≤ K₁ − G₁^{-1}((φ₂/φ₁) G₂(K₂))}` of Theorem 2. -/
noncomputable def singleRegion (M : Model) (a : Fin 2 → ℝ) : Set ℝ :=
  Set.Icc 0 (M.K 0 - M.B a)

/-- The quantity-hedge region `Ω₃ ∪ Ω₄ ∪ Ω₅ = {x : K₁ + K₂ − (G₁^{-1}(φ₂) + G₂^{-1}(φ₁)) < x ≤ K₁ + K₂}`
of Theorem 2 (the union is the same under the printed and the corrected bounds of `Ω₃, Ω₄, Ω₅`). -/
noncomputable def hedgeRegion (M : Model) (a : Fin 2 → ℝ) : Set ℝ :=
  Set.Ioc (M.K 0 + M.K 1 - (M.A1 a + M.A2 a)) (M.K 0 + M.K 1)

/-- Total order quantity `q₁* + q₂*` of the optimal vector of Theorem 2 (deterministic demand `x`,
`η = 0`), read off its region table with the corrected region bounds. With
`A₁ = G₁^{-1}(φ₂)`, `A₂ = G₂^{-1}(φ₁)` and `S = K₁ + K₂`:
`x` on `Ω₁ ∪ Ω₂` (`x ≤ S − (A₁ + A₂)`), where `q₁* + q₂* = x`;
`Ω₃` (up to `S − max(A₁, A₂)`), where `q* = (x − (K₂ − A₂), x − (K₁ − A₁))`;
`Ω₄` (up to `S − min(A₁, A₂)`), where `q* = (x − (K₂ − A₂), K₂)` if `A₁ ≥ A₂` and
`q* = (K₁, x − (K₁ − A₁))` otherwise; and `Ω₅ ∪ Ω₆`, where `q* = (K₁, K₂)`. -/
noncomputable def qstarTotal (M : Model) (a : Fin 2 → ℝ) (x : ℝ) : ℝ :=
  let A₁ := M.A1 a
  let A₂ := M.A2 a
  let S := M.K 0 + M.K 1
  if x ≤ S - (A₁ + A₂) then x
  else if x ≤ S - max A₁ A₂ then (x - (M.K 1 - A₂)) + (x - (M.K 0 - A₁))
  else if x ≤ S - min A₁ A₂ then
    (if A₂ ≤ A₁ then (x - (M.K 1 - A₂)) + M.K 1 else M.K 0 + (x - (M.K 0 - A₁)))
  else S

end Model

end MitigateSupplyRisk.DualSourcing
