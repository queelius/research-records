# Verified dual-sourcing optimal orders and reliability comparisons

Version 1.2.0 · [10.5281/zenodo.23540084](https://doi.org/10.5281/zenodo.23540084). Identifiers were reserved during assembly; the separate publication receipt establishes public availability. See NOTE.md for the six full results, distinct assumptions,
pre-existing platform repairs, proof ideas, attribution and limits.

## Reproduce

```sh
python3 scripts/verify_archive.py --integrity-only
python3 scripts/verify_archive.py --setup
```

Expected: six complete target audits and two freshly built platform definitions,
Lean 4.33.1/Mathlib pins, autoImplicit=false and only standard axioms. Initial
setup needs network and disk space but no platform credentials. Verified caches
remain trusted inputs. See verification/README.md.

Seven invalid controls must reject; see verification/receipt.json. Target JSON
contains original by-sorry statement text, never an accepted proof. Accepted
proof/audit bytes are unchanged. MANIFEST.json inventories packet files.

Both earlier editions are preserved under versions/. Theorem2 proves the
corrected deterministic optimizer regions. Corollary1 compares defined hedge
sizes/regions under its own assumptions; no individual quantity monotonicity or
optimality beyond Theorem2 hypotheses is claimed. Publication adds no target,
mathematical novelty or independent human review.
