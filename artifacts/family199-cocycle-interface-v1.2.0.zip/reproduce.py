"""Reproduce all three source-pinned components of the Family199 archive."""
from pathlib import Path
import subprocess
import sys
base = Path(__file__).resolve().parent
for packet in ("cocycle", "homotopy", "parameters"):
    subprocess.run([sys.executable, str(base / "source" / packet / "reproduce.py")], check=True)
print("RESULT: Family199 finite interface, homotopy and parameter audit archive reproduced")
