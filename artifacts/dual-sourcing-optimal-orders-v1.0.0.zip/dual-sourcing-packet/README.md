# Dual-sourcing submodularity and optimal orders

Version 1.0.0 · [10.5281/zenodo.23531695](https://doi.org/10.5281/zenodo.23531695). Identifiers were reserved during assembly; the separate publication receipt establishes public availability. See NOTE.md for the exact assumptions, two completed statements,
proof ideas, source comparison, credits and limitations. The two accepted Lean
proofs and their sole platform definition are included. Original mathematics:
Yimin Wang, Wendell Gilland and Brian Tomlin (2010), Lemma 1 and Theorem 1.
Their paper is cited, not redistributed.

## Reproduce

On Linux/POSIX with Python 3.10+, Git and elan, from this directory:

```sh
python3 scripts/verify_archive.py --integrity-only
python3 scripts/verify_archive.py --setup
```

First setup needs network and several GB of disk, without platform credentials.
Lean 4.33.1 and immutable Mathlib pins are supplied. The verifier rebuilds the
one platform definition and checks both full target signatures with
`autoImplicit=false`. Expected: `status: passed`, two compiled targets, only
`propext`, `Classical.choice`, `Quot.sound`. Verified third-party compiled caches
are trusted inputs. See verification/README.md for explicit cache reuse.

## Evidence and controls

Accepted proof and exact-audit bytes are unchanged. Historical filesystem
prefixes are normalized with original and portable hashes retained. Theorem 1
reuses the accepted Lemma 1 body inline with a declaration rename; neither
proof imports a platform theorem. JSON files in targets/ retain original
by-sorry statements solely as historical target text.

Invalid controls intentionally alter a proof byte, weaken a target or add a
local axiom. Each must be rejected; none was submitted. Their outcomes are in
verification/receipt.json. MANIFEST.json inventories every packet file except
itself. See provenance.json, NOTICE.md, LICENSE and CITATION.cff for credits.

This archive adds no accepted target. It proves no sufficient first-order
condition, explicit CDF formula, region characterization or comparative
statics. Mathematical novelty, source-author endorsement and independent
human proof review are not claimed.
