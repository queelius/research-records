import Mathlib

open MeasureTheory ProbabilityTheory

namespace MitigateSupplyRisk.DualSourcing

/-- The two-supplier random-capacity newsvendor of Wang, Gilland and Tomlin (2010), §3.1–3.2,
without process improvement. Suppliers are indexed by `Fin 2`: index `0` is the paper's supplier 1
and index `1` is its supplier 2.

* `r`, `v`, `p`: unit revenue, salvage value and penalty cost for unfilled demand.
* `c i`, `η i`, `K i`: unit cost, committed-cost fraction and design capacity of supplier `i`.
* `ν i a`: the law of supplier `i`'s capacity loss `ξ_i` when its reliability index is `a`.

Standing assumptions of §3: `0 ≤ η i ≤ 1`; capacity losses are nonnegative and continuously
distributed; a larger reliability index makes the capacity-loss CDF pointwise larger
(`G_i(·, a) ≤ G_i(·, â)` for `a ≤ â`). Added and disclosed: `0 < K i`, `v < r + p` (the
denominator of `ψ`, `φ` in Eq. (2)), and `r, p, c i ≥ 0` (revenue, penalty and cost are
nonnegative amounts), which keep the profit bounded above in the order quantities. -/
structure Model where
  r : ℝ
  v : ℝ
  p : ℝ
  c : Fin 2 → ℝ
  η : Fin 2 → ℝ
  K : Fin 2 → ℝ
  ν : Fin 2 → ℝ → Measure ℝ
  ν_prob : ∀ i a, IsProbabilityMeasure (ν i a)
  ν_nonneg : ∀ i a, ν i a (Set.Iio 0) = 0
  ν_noAtoms : ∀ i a t, ν i a {t} = 0
  ν_mono : ∀ i a a', a ≤ a' → ∀ t, cdf (ν i a) t ≤ cdf (ν i a') t
  η_nonneg : ∀ i, 0 ≤ η i
  η_le_one : ∀ i, η i ≤ 1
  K_pos : ∀ i, 0 < K i
  r_nonneg : 0 ≤ r
  p_nonneg : 0 ≤ p
  c_nonneg : ∀ i, 0 ≤ c i
  v_lt : v < r + p

namespace Model

instance (M : Model) (i : Fin 2) (a : ℝ) : IsProbabilityMeasure (M.ν i a) := M.ν_prob i a

/-- `G_i(t, a)`: the distribution function of supplier `i`'s capacity loss at reliability index `a`. -/
noncomputable def G (M : Model) (i : Fin 2) (t a : ℝ) : ℝ := cdf (M.ν i a) t

/-- `ψ_i = −η_i c_i / (r + p − v)` (§3.3, before Eq. (2)). -/
noncomputable def psi (M : Model) (i : Fin 2) : ℝ := -(M.η i * M.c i) / (M.r + M.p - M.v)

/-- `φ_i = (r + p − (1 − η_i) c_i) / (r + p − v)` (§3.3, before Eq. (2)). -/
noncomputable def phi (M : Model) (i : Fin 2) : ℝ :=
  (M.r + M.p - (1 - M.η i) * M.c i) / (M.r + M.p - M.v)

/-- Delivered quantity `y_i = min{q_i, (K_i − ξ_i)⁺}` (§3.2). -/
def deliv (K q ξ : ℝ) : ℝ := min q (max (K - ξ) 0)

/-- Realized profit `π(q)` of Eq. (1), for order vector `q`, capacity losses `ξ` and realized
demand `x`. -/
noncomputable def profit (M : Model) (q ξ : Fin 2 → ℝ) (x : ℝ) : ℝ :=
  -(∑ i, (M.η i * q i + (1 - M.η i) * deliv (M.K i) (q i) (ξ i)) * M.c i)
    + M.r * min x (∑ i, deliv (M.K i) (q i) (ξ i))
    + M.v * max ((∑ i, deliv (M.K i) (q i) (ξ i)) - x) 0
    - M.p * max (x - ∑ i, deliv (M.K i) (q i) (ξ i)) 0

/-- Second-stage expected profit `Π₂(q; a) = E_{ξ(a), X}[π(q)]` (Eq. (3)), with the capacity
losses independent with laws `ν i (a i)` and independent of the demand `X ~ μ`. For a demand law
with finite mean the integrand is integrable for every `q` (`|π| ≤ C_q (1 + |x|)`), so the
Bochner integral is the genuine expectation. -/
noncomputable def Pi2 (M : Model) (μ : Measure ℝ) (q a : Fin 2 → ℝ) : ℝ :=
  ∫ ω, M.profit q ω.1 ω.2 ∂((Measure.pi fun i => M.ν i (a i)).prod μ)

/-- The feasible order vectors `q ≥ 0`. -/
def orders : Set (Fin 2 → ℝ) := {q | ∀ i, 0 ≤ q i}

/-- Optimal second-stage profit `Π₂*(a) = max_{q ≥ 0} Π₂(q; a)` (§3.3). The image is nonempty and,
since `r, p, c i ≥ 0`, `y_i ≤ K_i` and demand is nonnegative, bounded above by
`(r + |v|)(K₁ + K₂)`; so the supremum is not a junk value. -/
noncomputable def Pi2star (M : Model) (μ : Measure ℝ) (a : Fin 2 → ℝ) : ℝ :=
  sSup ((fun q => M.Pi2 μ q a) '' orders)

/-- `q` is an optimal procurement vector at reliability indices `a` and demand law `μ`: it is
feasible (`q ≥ 0`) and maximizes `Π₂(·; a)` over all feasible order vectors. -/
def IsOptimal (M : Model) (μ : Measure ℝ) (a q : Fin 2 → ℝ) : Prop :=
  q ∈ orders ∧ ∀ q' ∈ orders, M.Pi2 μ q' a ≤ M.Pi2 μ q a

end Model

end MitigateSupplyRisk.DualSourcing
