import Mathlib
import Definitions.Def_ThreeOpSplitting_ConvexRates_Problem
import Definitions.Def_MoreauProx_Characterization_GammaZero
import Definitions.Def_RelaxedPRS_BestIter_Setting
import Definitions.Def_RelaxedPRS_StrongCvx_Setting

namespace RelaxedPRS.Linear

/-- The factor in Theorem 4.1, p. 14. -/
noncomputable def C41 (γ μg βg t : ℝ) : ℝ :=
  Real.sqrt (1 - 4 * γ * t * μg / (1 + γ / βg) ^ 2)

/-- The factor in Theorem 4.2, p. 15. -/
noncomputable def C42 (γ μf βf t : ℝ) : ℝ :=
  Real.sqrt (1 - t / 2 * min (4 * γ * μf / (1 + γ / βf) ^ 2) (1 - t))

/-- The factor in Theorem 4.3, p. 16. -/
noncomputable def C43 (γ μ β t : ℝ) : ℝ :=
  Real.sqrt (1 - 4 * t / 3 * min (min (γ * μ) (β / γ)) (1 - t))

end RelaxedPRS.Linear
