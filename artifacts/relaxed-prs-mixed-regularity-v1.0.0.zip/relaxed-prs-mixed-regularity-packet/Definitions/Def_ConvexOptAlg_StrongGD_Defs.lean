import Mathlib

open scoped InnerProductSpace

namespace ConvexOptAlg.StrongGD

abbrev E (n : ℕ) := EuclideanSpace ℝ (Fin n)

/-- The book's β-smoothness: the actual gradient is β-Lipschitz. -/
def IsBetaSmooth {n : ℕ} (f : E n → ℝ) (g : E n → E n) (β : ℝ) : Prop :=
  (∀ x : E n, HasGradientAt f (g x) x) ∧
  0 ≤ β ∧ ∀ x y : E n, ‖g x - g y‖ ≤ β * ‖x - y‖

/-- The unconstrained gradient-descent recurrence, with the book's first iterate at index 1. -/
def IsGDRun {n : ℕ} (g : E n → E n) (η : ℝ) (x : ℕ → E n) : Prop :=
  ∀ t : ℕ, 1 ≤ t → x (t + 1) = x t - η • g (x t)

/-- The auxiliary function φ(z) = f(z) − (α/2)‖z‖² from Lemma 3.11. -/
noncomputable def phi {n : ℕ} (f : E n → ℝ) (α : ℝ) (z : E n) : ℝ :=
  f z - (α / 2) * ‖z‖ ^ 2

end ConvexOptAlg.StrongGD
