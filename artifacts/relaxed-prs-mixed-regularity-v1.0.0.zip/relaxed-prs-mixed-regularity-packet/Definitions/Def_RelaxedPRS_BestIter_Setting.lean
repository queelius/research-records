import Mathlib
import Definitions.Def_ThreeOpSplitting_ConvexRates_Problem
import Definitions.Def_MoreauProx_Characterization_GammaZero
import Definitions.Def_RelaxedPRS_StrongCvx_Setting

namespace RelaxedPRS.BestIter

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- Lemma 1.1's auxiliary point x_g = prox_{γg}(z). -/
def xg (Pg : H → H) (z : H) : H := Pg z

/-- The objective error f(x) + g(x) − f(x*) − g(x*) as a real number. It is faithful only where
`f x`, `g x`, `f xs`, `g xs` are finite; every item of this mission uses it only at such points
(a prox output of a proper function, or any point of a function with a Lipschitz gradient, which
is real-valued). -/
noncomputable def objErr (f g : H → EReal) (xs x : H) : ℝ :=
  (f x).toReal + (g x).toReal - (f xs).toReal - (g xs).toReal

end RelaxedPRS.BestIter
