import Mathlib
open scoped InnerProductSpace

namespace MoreauProx.Characterization

/-- Convexity of a function `φ : H → ]−∞, +∞]` (encoded in `EReal`): its epigraph
`{(x, t) ∈ H × ℝ | φ x ≤ t}` is a convex subset of `H × ℝ`. For functions that never take the
value `⊥` this is the usual convexity inequality with the conventions of `]−∞, +∞]`. -/
def EConvex {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (φ : H → EReal) : Prop :=
  Convex ℝ {p : H × ℝ | φ p.1 ≤ ((p.2 : ℝ) : EReal)}

/-- Moreau §2.a: `Γ₀(H)`, the functions `H → ]−∞, +∞]` that are convex and lower semicontinuous
and not identically `+∞` (the paper's stated equivalent of "upper envelope of a nonempty family
of continuous affine functions, other than the constants ±∞"). -/
def GammaZero {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (f : H → EReal) : Prop :=
  (∀ x, f x ≠ ⊥) ∧ (∃ x, f x ≠ ⊤) ∧ EConvex f ∧ LowerSemicontinuous f

/-- Moreau (2.2): the dual (conjugate) function `g(y) = sup_{x ∈ H} [(x | y) − f(x)]`,
computed in `EReal` (where `a − ⊤ = ⊥`, so points with `f x = +∞` contribute nothing). -/
noncomputable def conj {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (f : H → EReal) (y : H) : EReal :=
  ⨆ x : H, ((⟪x, y⟫_ℝ : ℝ) : EReal) - f x

/-- Moreau §2.c: `y` is a subgradient of `φ` at `z` when `φ z` is finite and the continuous
affine function `u ↦ (u − z | y) + φ(z)` minorizes `φ` (an affine minorant exact at `z`).
`subgrad φ z` is the set `∂φ(z)`. -/
def subgrad {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (φ : H → EReal) (z : H) : Set H :=
  {y | φ z ≠ ⊥ ∧ φ z ≠ ⊤ ∧ ∀ u : H, φ z + ((⟪u - z, y⟫_ℝ : ℝ) : EReal) ≤ φ u}

end MoreauProx.Characterization
