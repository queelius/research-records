import Mathlib
import Definitions.Def_ThreeOpSplitting_ConvexRates_Problem
import Definitions.Def_MoreauProx_Characterization_GammaZero

open scoped InnerProductSpace
open Finset

namespace RelaxedPRS.StrongCvx

/-- The reflection `2 prox_{γ f} - I` of §1.2, p. 4. -/
def refl {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (P : H → H) (z : H) : H := (2 : ℝ) • P z - z

/-- The Peaceman–Rachford operator `refl_{γ f} ∘ refl_{γ g}`. -/
def TPRS {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (Pf Pg : H → H) (z : H) : H := refl Pf (refl Pg z)

/-- The averaged PRS operator `(1-λ)I + λ T_PRS`. -/
def Tlam {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (Pf Pg : H → H) (lam : ℝ) (z : H) : H :=
  (1 - lam) • z + lam • TPRS Pf Pg z

/-- Algorithm 1, p. 5, with its relaxation bound imposed on each theorem using a run. -/
def IsPRSRun {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (Pf Pg : H → H) (lam : ℕ → ℝ) (z : ℕ → H) : Prop :=
  ∀ k, z (k + 1) = (1 - lam k) • z k + lam k • TPRS Pf Pg (z k)

/-- The first auxiliary point of Lemma 1.1. -/
def xg {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (Pg : H → H) (z : H) : H := Pg z

/-- The second auxiliary point of Lemma 1.1. -/
def xf {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (Pf Pg : H → H) (z : H) : H := Pf (refl Pg z)

/-- The proximal subgradient of `g` selected in Lemma 1.1. -/
noncomputable def gtG {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (γ : ℝ) (Pg : H → H) (z : H) : H := γ⁻¹ • (z - xg Pg z)

/-- The proximal subgradient of `f` selected in Lemma 1.1. -/
noncomputable def gtF {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (γ : ℝ) (Pf Pg : H → H) (z : H) : H :=
  γ⁻¹ • (refl Pg z - xf Pf Pg z)

/-- Strong convexity for a proper extended-real function, §1.10, p. 7. -/
def IsStrongCvxE {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (μ : ℝ) (f : H → EReal) : Prop :=
  ∀ x y : H, ∀ t : ℝ, 0 ≤ t → t ≤ 1 →
    f (t • x + (1 - t) • y) + ((μ / 2 * t * (1 - t) * ‖x - y‖ ^ 2 : ℝ) : EReal)
      ≤ (t : EReal) * f x + ((1 - t : ℝ) : EReal) * f y

/-- A positive `β` certifies that `f` is real-valued, differentiable, and has a
`β⁻¹`-Lipschitz gradient. The implication at `β = 0` is imposed in theorem statements. -/
def HasLipGrad {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    [CompleteSpace H] (β : ℝ) (f : H → EReal) : Prop :=
  ∃ h : H → ℝ, (∀ x, f x = (h x : EReal)) ∧
    ThreeOpSplitting.ConvexRates.IsSmoothConvex β h

/-- The regularity term `S_f(x,y)` of (1.14), for specified subgradients
`u ∈ ∂f(x)` and `v ∈ ∂f(y)`. -/
noncomputable def auxS {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (μ β : ℝ) (x y u v : H) : ℝ :=
  max (μ / 2 * ‖x - y‖ ^ 2) (β / 2 * ‖u - v‖ ^ 2)

/-- The partial sum `Λ_k` of (1.3), including the zeroth weight. -/
def Lam (lam : ℕ → ℝ) (k : ℕ) : ℝ := ∑ i ∈ Finset.range (k + 1), lam i

/-- The weighted ergodic average of §1.2. In theorems its weights are strictly
positive, so `Λ_k` never vanishes. -/
noncomputable def ergAvg {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (lam : ℕ → ℝ) (w : ℕ → H) (k : ℕ) : H :=
  (Lam lam k)⁻¹ • ∑ i ∈ Finset.range (k + 1), lam i • w i

end RelaxedPRS.StrongCvx
