import Definitions.Def_InfFisher_Linear_Market
import Definitions.Def_InfFisher_EG_Setting

namespace InfFisher.Linear

open MeasureTheory
variable {α : Type*} [MeasurableSpace α]

/-- The linear valuations of §4, indexed by buyer numbers starting at zero. -/
def linVal (c d : ℕ → ℝ) (n : ℕ) : Fin n → ℝ → ℝ :=
  fun i θ => c i.val * θ + d i.val

/-- Assumption 1: normalized, nonnegative linear valuations with strictly decreasing intercepts. -/
noncomputable def Assumption1 (n : ℕ) (c d : ℕ → ℝ) : Prop :=
  (∀ i < n, ∀ θ ∈ Set.Icc (0 : ℝ) 1, 0 ≤ c i * θ + d i) ∧
  (∀ i < n, c i / 2 + d i = 1) ∧
  (∀ i < n, d i ≤ 2 ∧ 0 ≤ d i) ∧
  (∀ i j, i < j → j < n → d j < d i)

/-- The epigraph of the square, denoted `𝒞` in Theorem 4. -/
def paraCone : Set (ℝ × ℝ) := {q | q.1 ^ 2 ≤ q.2}

/-- The matrix `Gᵢ` of Theorem 4 applied to `(sᵢ,tᵢ)`. -/
noncomputable def Gmap (c d : ℕ → ℝ) (k : ℕ) (s t : ℝ) : ℝ × ℝ :=
  (d k * s + c k / 2 * t, -(d (k + 1)) * s - c (k + 1) / 2 * t)

/-- All auxiliary constraints of Theorem 4, for a fixed utility vector. -/
def conicConstraints (n : ℕ) (c d : ℕ → ℝ)
    (u : Fin n → ℝ) (z w s t : ℕ → ℝ) : Prop :=
  (∀ i : Fin n, i.val = 0 → u i ≤ z 0) ∧
  (∀ i : Fin n, 1 ≤ i.val → i.val ≤ n - 2 →
    u i ≤ z i.val + w (i.val - 1)) ∧
  (∀ i : Fin n, i.val = n - 1 → u i ≤ 1 + w (n - 2)) ∧
  (∀ k < n - 1,
    Gmap c d k (s k) (t k) = (z k, w k) ∧
    (s k, t k) ∈ paraCone ∧
    z k ∈ Set.Icc (0 : ℝ) 1 ∧
    w k ∈ Set.Icc (-1 : ℝ) 0 ∧
    0 ≤ z k + w k)

/-- The projected conic representation of the feasible utility set. -/
def conicRep (n : ℕ) (c d : ℕ → ℝ) (u : Fin n → ℝ) : Prop :=
  (∀ i, 0 ≤ u i) ∧ ∃ z w s t : ℕ → ℝ, conicConstraints n c d u z w s t

end InfFisher.Linear
