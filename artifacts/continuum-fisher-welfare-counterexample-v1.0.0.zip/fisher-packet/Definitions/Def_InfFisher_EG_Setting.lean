import Mathlib
import Definitions.Def_InfFisher_EG_Market

namespace InfFisher.EG

open MeasureTheory
variable {α : Type*} [MeasurableSpace α]

def pureUtil (μ : Measure α) (Θ : Set α) {n : ℕ}
    (v : Fin n → α → ℝ) : Set (Fin n → ℝ) :=
  {u | ∃ S : Fin n → Set α,
    (∀ i, MeasurableSet (S i) ∧ S i ⊆ Θ) ∧
    (∀ i j, i ≠ j → μ (S i ∩ S j) = 0) ∧
    ∀ i, u i = ∫ θ in S i, v i θ ∂μ}

noncomputable def dualRed (μ : Measure α) {n : ℕ}
    (v : Fin n → α → ℝ) (B β : Fin n → ℝ) : ℝ :=
  (∫ θ, maxScaled v β θ ∂μ) - ∑ i, B i * Real.log (β i)

def IsParetoOptimal (μ : Measure α) {n : ℕ}
    (v : Fin n → α → ℝ) (x : Fin n → α → ℝ) : Prop :=
  IsAllocation μ x ∧
  ¬ ∃ x', IsAllocation μ x' ∧
    (∀ i, pair μ (v i) (x i) ≤ pair μ (v i) (x' i)) ∧
    ∃ i, pair μ (v i) (x i) < pair μ (v i) (x' i)

def IsEnvyFree (μ : Measure α) {n : ℕ}
    (v : Fin n → α → ℝ) (B : Fin n → ℝ)
    (x : Fin n → α → ℝ) : Prop :=
  ∀ i j, j ≠ i →
    (1 / B j) * pair μ (v i) (x j) ≤
    (1 / B i) * pair μ (v i) (x i)

def IsProportional (μ : Measure α) {n : ℕ}
    (v : Fin n → α → ℝ) (B : Fin n → ℝ)
    (x : Fin n → α → ℝ) : Prop :=
  ∀ i, B i / (∑ j, B j) * (∫ θ, v i θ ∂μ) ≤ pair μ (v i) (x i)

def IsAtomless {Ω : Type*} [MeasurableSpace Ω] (m : Measure Ω) : Prop :=
  ∀ (A : Set Ω) (c : ENNReal), MeasurableSet A →
    0 < c → c < m A → ∃ B, B ⊆ A ∧ MeasurableSet B ∧ m B = c

def dwwX {Ω : Type*} [MeasurableSpace Ω] (p : ℕ) : Set (Fin p → Ω → ℝ) :=
  {x | (∀ j, Measurable (x j) ∧ ∀ θ, 0 ≤ x j θ) ∧
    ∀ θ, ∑ j, x j θ = 1}

def dwwS {Ω : Type*} [MeasurableSpace Ω] (p : ℕ) : Set (Fin p → Set Ω) :=
  {S | (∀ j, MeasurableSet (S j)) ∧
    (∀ j k, j ≠ k → S j ∩ S k = ∅) ∧
    (⋃ j, S j) = Set.univ}

def dwwU {Ω : Type*} [MeasurableSpace Ω] {m : ℕ}
    (μs : Fin m → Measure Ω) (p : ℕ) : Set (Fin m → Fin p → ℝ) :=
  {u | ∃ x ∈ dwwX p, ∀ i j, u i j = ∫ θ, x j θ ∂(μs i)}

def dwwU' {Ω : Type*} [MeasurableSpace Ω] {m : ℕ}
    (μs : Fin m → Measure Ω) (p : ℕ) : Set (Fin m → Fin p → ℝ) :=
  {u | ∃ S ∈ dwwS p, ∀ i j, u i j = (μs i (S j)).toReal}

end InfFisher.EG
