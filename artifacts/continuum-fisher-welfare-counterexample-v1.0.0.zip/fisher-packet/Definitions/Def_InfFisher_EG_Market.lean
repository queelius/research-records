import Mathlib

namespace InfFisher.EG

open MeasureTheory
variable {α : Type*} [MeasurableSpace α]

noncomputable def pair (μ : Measure α) (f g : α → ℝ) : ℝ := ∫ θ, f θ * g θ ∂μ

def IsBundle (μ : Measure α) (y : α → ℝ) : Prop :=
  MemLp y ⊤ μ ∧ 0 ≤ᵐ[μ] y

def IsAllocation (μ : Measure α) {n : ℕ} (x : Fin n → α → ℝ) : Prop :=
  (∀ i, IsBundle μ (x i)) ∧ ∀ᵐ θ ∂μ, ∑ i, x i θ ≤ 1

def IsPrice (μ : Measure α) (p : α → ℝ) : Prop :=
  Integrable p μ ∧ 0 ≤ᵐ[μ] p

def IsPure (μ : Measure α) (Θ : Set α) {n : ℕ} (x : Fin n → α → ℝ) : Prop :=
  ∃ S : Fin n → Set α,
    (∀ i, MeasurableSet (S i) ∧ S i ⊆ Θ) ∧
    (∀ i j, i ≠ j → μ (S i ∩ S j) = 0) ∧
    ∀ i, x i =ᵐ[μ] (S i).indicator (fun _ => (1 : ℝ))

def InDemand (μ : Measure α) {n : ℕ} (v : Fin n → α → ℝ)
    (B : Fin n → ℝ) (p : α → ℝ) (i : Fin n) (y : α → ℝ) : Prop :=
  IsBundle μ y ∧ pair μ p y ≤ B i ∧
  ∀ y', IsBundle μ y' → pair μ p y' ≤ B i → pair μ (v i) y' ≤ pair μ (v i) y

def IsME (μ : Measure α) {n : ℕ} (v : Fin n → α → ℝ)
    (B : Fin n → ℝ) (x : Fin n → α → ℝ) (p : α → ℝ) : Prop :=
  IsPrice μ p ∧ IsAllocation μ x ∧
  (∀ i, InDemand μ v B p i (x i)) ∧
  pair μ p (fun θ => 1 - ∑ i, x i θ) = 0

noncomputable def pegObj (μ : Measure α) {n : ℕ} (v : Fin n → α → ℝ)
    (B : Fin n → ℝ) (x : Fin n → α → ℝ) : ℝ :=
  ∑ i, B i * Real.log (pair μ (v i) (x i))

def IsPEGOptimal (μ : Measure α) {n : ℕ} (v : Fin n → α → ℝ)
    (B : Fin n → ℝ) (x : Fin n → α → ℝ) : Prop :=
  IsAllocation μ x ∧ (∀ i, 0 < pair μ (v i) (x i)) ∧
  ∀ x', IsAllocation μ x' → (∀ i, 0 < pair μ (v i) (x' i)) →
    pegObj μ v B x' ≤ pegObj μ v B x

def IsDEGFeasible (μ : Measure α) {n : ℕ} (v : Fin n → α → ℝ)
    (p : α → ℝ) (β : Fin n → ℝ) : Prop :=
  IsPrice μ p ∧ (∀ i, 0 ≤ β i) ∧
  ∀ i, (fun θ => β i * v i θ) ≤ᵐ[μ] p

noncomputable def degObj (μ : Measure α) {n : ℕ}
    (B : Fin n → ℝ) (p : α → ℝ) (β : Fin n → ℝ) : ℝ :=
  (∫ θ, p θ ∂μ) - ∑ i, B i * Real.log (β i)

def IsDEGOptimal (μ : Measure α) {n : ℕ} (v : Fin n → α → ℝ)
    (B : Fin n → ℝ) (p : α → ℝ) (β : Fin n → ℝ) : Prop :=
  IsDEGFeasible μ v p β ∧ (∀ i, 0 < β i) ∧
  ∀ p' β', IsDEGFeasible μ v p' β' → (∀ i, 0 < β' i) →
    degObj μ B p β ≤ degObj μ B p' β'

noncomputable def maxScaled {n : ℕ} (v : Fin n → α → ℝ)
    (β : Fin n → ℝ) : α → ℝ :=
  fun θ => ⨆ i, β i * v i θ

def feasUtil (μ : Measure α) {n : ℕ} (v : Fin n → α → ℝ) : Set (Fin n → ℝ) :=
  {u | ∃ x, IsAllocation μ x ∧ ∀ i, u i = pair μ (v i) (x i)}

end InfFisher.EG
