# A continuum Fisher welfare counterexample

Version 1.0.0 · [10.5281/zenodo.23527887](https://doi.org/10.5281/zenodo.23527887). Identifiers were reserved during assembly; the separate publication receipt establishes public availability. See NOTE.md for the exact model, counterexample, proof, source
comparison, credit and limitations. One accepted full quantified disproof and
all four platform definition modules are included. The original model and
statement are credited to Yuan Gao and Christian Kroer; the pinned source
paper is cited, not redistributed.

## Reproduce

On Linux/POSIX with Python 3.10+, Git and elan, from this directory:

```sh
python3 scripts/verify_archive.py --integrity-only
python3 scripts/verify_archive.py --setup
```

First setup needs network and several GB of disk, without platform credentials.
Lean 4.33.1 and immutable Mathlib pins are supplied. The verifier rebuilds all
four platform definitions and checks the full quantified negation with
`autoImplicit=false`. Expected report: `status: passed`, one compiled target,
only `propext`, `Classical.choice`, `Quot.sound`. Verified third-party compiled
caches are trusted inputs. See verification/README.md for cache reuse.

## Evidence and controls

Proof and independent audit bytes are unchanged. Historical command and log
filesystem prefixes are normalized with original and portable hashes retained.
The proof imports no platform theorem; target.json retains the original
by-sorry statement only as historical text. Invalid controls intentionally
change a proof byte, weaken the conclusion or add a local axiom. Each must be
rejected, and none was submitted. verification/receipt.json records outcomes.
MANIFEST.json inventories every packet file except itself. See provenance.json,
NOTICE.md, LICENSE and CITATION.cff for attribution, source pins and citation.

This archive adds no accepted target. It does not refute the separate sorted
linear-valuation theorem or establish a repaired welfare theorem. No novelty,
independent human proof review or source-author endorsement is claimed.
