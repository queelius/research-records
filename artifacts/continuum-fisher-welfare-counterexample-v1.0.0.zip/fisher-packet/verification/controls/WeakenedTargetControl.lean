import Mathlib
import Definitions.Def_InfFisher_Linear_Setting
open MeasureTheory
set_option autoImplicit false
theorem solution : True := by trivial

-- Independent audit against the complete quantified platform signature.
example : ¬ (∀ {d n : ℕ} (Θ : Set (EuclideanSpace ℝ (Fin d)))
    (hΘ : IsCompact Θ)
    (v : Fin n → EuclideanSpace ℝ (Fin d) → ℝ)
    (hv : ∀ i, Integrable (v i) (volume.restrict Θ))
    (hv0 : ∀ i, 0 ≤ᵐ[volume.restrict Θ] v i)
    (hvpos : ∀ i, 0 < ∫ θ in Θ, v i θ)
    (x : Fin n → EuclideanSpace ℝ (Fin d) → ℝ)
    (hx : InfFisher.EG.IsParetoOptimal (volume.restrict Θ) v x),
    ∃ B : Fin n → ℝ, (∀ i, 0 ≤ B i) ∧
      ∃ p, InfFisher.Linear.IsME (volume.restrict Θ) v B x p) := solution
#print axioms solution


-- Generated proof_workflow guard; keep the independent audit above.
run_cmd do
  let env ← Lean.getEnv
  let some info := env.find? `solution | throwError "Missing top-level solution"
  unless info.isTheorem do throwError "solution must be a theorem"
  if env.isImportedConst `solution then throwError "solution must be local"
  let forbidden : String := "Theorems.Thm_InfFisher_Linear_lemma_6"
  for moduleName in env.header.moduleNames do
    if moduleName.toString == forbidden then throwError "Circular target import"
    if moduleName.toString.startsWith "Theorems." then throwError "Disproof imports platform theorem"
  let allowed : Array Lean.Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let localDecls := env.constants.foldStage2 (fun xs n c => xs.push (n, c)) #[]
  for (name, decl) in localDecls do
    if !env.isImportedConst name then
      if decl.isAxiom then throwError "Local axiom is forbidden: {name}"
      for axiomName in (← Lean.collectAxioms name) do
        unless allowed.contains axiomName do
          throwError "Unexpected axiom in local declaration: {axiomName}"
  let axioms ← Lean.collectAxioms `solution
  for axiomName in axioms do
    unless allowed.contains axiomName do
      throwError "Unexpected axiom in solution: {axiomName}"
  let data := Lean.Json.arr (axioms.map fun n => Lean.Json.str n.toString)
  IO.println ("PROOF_WORKFLOW_AXIOMS e6c520d4eb3c4ba6a88fca7636a9c6e3 " ++ data.compress)
