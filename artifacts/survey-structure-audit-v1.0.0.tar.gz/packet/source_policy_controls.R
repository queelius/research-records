# Synthetic source-policy controls, base R only. Never empirical NEON observations.
# Extract and evaluate the author's actual join_cols assignments as parsed R AST.
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 2L, dir.exists(args[[2L]]))
expressions <- parse(args[[1L]])
is_assignment_to <- function(expr, name) {
    is.call(expr) && identical(expr[[1L]], as.name('<-')) &&
        identical(expr[[2L]], as.name(name))
}
assignment <- Filter(function(x) is_assignment_to(x, 'clean_neon_bird'), as.list(expressions))
stopifnot(length(assignment) == 1L)
fun <- eval(assignment[[1L]][[3L]], envir = baseenv())
key_statements <- Filter(function(x) is_assignment_to(x, 'join_cols'), as.list(body(fun))[-1L])
stopifnot(length(key_statements) == 2L)

point <- data.frame(uid='p1', siteID='S', plotID='G', pointID='1', eventID='E',
                    startDate='2020-06-01 10:00:00', samplingImpractical='OK',
                    remarks='initial', stringsAsFactors=FALSE)
counts <- data.frame(uid=c('c1','c2'), siteID='S', plotID='G', pointID='1', eventID='E',
                     startDate='2020-06-01 10:00:00', pointCountMinute=1:2,
                     clusterSize=c(1,2), stringsAsFactors=FALSE)

derive_keys <- function(points, counts) {
    environment <- new.env(parent=baseenv())
    environment$brd_point <- points
    environment$brd_count <- counts
    for (statement in key_statements) eval(statement, envir=environment)
    environment$join_cols
}
write.csv(data.frame(key=derive_keys(point, counts)), file=file.path(args[[2L]],'join-keys.csv'), row.names=FALSE)

# Base-R semantic controls of the source's distinct/filter/downward-join/projection
# policy. This does NOT execute dplyr clean_neon_bird or certify the historical raw data.
# Retain the fields relevant to the counterexample: point timestamp and minute/value.
run_control <- function(name, points) {
    surveyed <- unique(points[points$samplingImpractical == 'OK', , drop=FALSE])
    clean_counts <- unique(counts)
    keys <- derive_keys(surveyed,clean_counts)
    # Same discarded count fields as the pinned select(any_of(...)) call.
    dropped <- c('uid','startDate','identifiedBy','measuredBy','samplingImpractical','samplingImpracticalRemarks')
    right <- clean_counts[, setdiff(names(clean_counts), dropped), drop=FALSE]
    merged <- merge(surveyed,right,by=keys,all.x=TRUE,sort=FALSE)
    projected <- unique(merged[,c('siteID','plotID','pointID','eventID','startDate','pointCountMinute','clusterSize'),drop=FALSE])
    write.csv(projected,file=file.path(args[[2L]],paste0('projection-',name,'.csv')),row.names=FALSE)
    data.frame(scenario=name, raw_points=nrow(points), surveyed_points=nrow(surveyed),
               matched_rows=nrow(merged), projected_unique_rows=nrow(projected),
               projected_cluster_size_sum=sum(projected$clusterSize), synthetic=TRUE)
}
repeated <- rbind(point,transform(point,uid='p2',startDate='2020-06-01 11:00:00',remarks='later'))
hidden <- rbind(point,transform(point,uid='p2'))
unobserved <- rbind(point,transform(point,uid='p2',pointID='2',samplingImpractical='logistical'))
output <- do.call(rbind,list(run_control('valid',point),
                            run_control('ambiguous_repeated_key',repeated),
                            run_control('hidden_uid_multiplicity',hidden),
                            run_control('unobserved_attempt_denominator',unobserved)))
write.csv(output,file=file.path(args[[2L]],'source-policy-controls.csv'),row.names=FALSE)
