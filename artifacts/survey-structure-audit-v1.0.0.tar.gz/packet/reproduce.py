"""Read-only offline scientific replay of this exact archived packet."""
import csv
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import tempfile

from analysis import PointSurvey, CountRecord, audit_join, design_effect, effort_audit, load_observations

HERE=Path(__file__).resolve().parent


def verify_pins(root):
    pins=json.loads((root/'pins.json').read_text())
    for item in pins['files']:
        relative=Path(item['path'])
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Unsafe pin path')
        path=root/relative
        if not path.is_file() or sha256(path.read_bytes()).hexdigest()!=item['sha256']:
            raise ValueError(f'Pinned bytes changed: {relative}')


def scientific_results(root):
    verify_pins(root)
    rows=load_observations(root/'data/observations.csv')
    if not rows or any(row.site!='HARV' or row.observed.year!=2020 for row in rows):
        raise ValueError('Fixed HARV2020 selection failed')
    observed=effort_audit(rows)
    with tempfile.TemporaryDirectory(prefix='bird-packet-') as temporary:
        controls=Path(temporary)
        subprocess.run(['Rscript',str(root/'source_policy_controls.R'),str(root/'predecessor/pinned-taxon-clean.R'),str(controls)],check=True,capture_output=True,text=True)
        with (controls/'source-policy-controls.csv').open() as handle:
            source_controls=list(csv.DictReader(handle))
        with (controls/'join-keys.csv').open() as handle:
            keys=[row['key'] for row in csv.DictReader(handle)]
        projection_hashes={path.name:sha256(path.read_bytes()).hexdigest() for path in sorted(controls.glob('projection-*.csv'))}
        for path in controls.glob('*.csv'):
            if path.read_bytes()!=(root/'expected-controls'/path.name).read_bytes():
                raise ValueError(f'Control mismatch: {path.name}')
    point=PointSurvey('S','G','P','E','2020-06-01T10:00:00','p1',True)
    repeated=PointSurvey('S','G','P','E','2020-06-01T11:00:00','p2',True)
    counts=[CountRecord('S','G','P','E','2020-06-01T10:00:00','c1',1,1),CountRecord('S','G','P','E','2020-06-01T10:00:00','c2',2,2)]
    result={'recording_structure':observed,
       'conditional_design_effects':{level:[design_effect(observed[sizes],rho) for rho in [0,0.05,0.10,0.25,0.50,1]] for level,sizes in [('rows_by_grid','grid_row_sizes'),('provisional_units_by_grid','grid_provisional_unit_sizes')]},
       'actual_author_key_extraction':{'method':'Evaluate the two join_cols assignments from pinned R AST using base R on synthetic table schemas.','keys':keys,'full_current_documented_key_present':all(key in keys for key in ['eventID','plotID','pointID'])},
       'synthetic_source_policy_controls':source_controls,'synthetic_projection_hashes':projection_hashes,
       'synthetic_typed_join_controls':{'intended_timestamp_control':audit_join([point,repeated],counts,('site','grid','point','event','start')),'ambiguous_repeated_point_key':audit_join([point,repeated],counts,('site','grid','point','event'))}}
    # Normalize tuples to their JSON representation, without replacing calculations.
    return json.loads(json.dumps(result))


def replay(root):
    result=scientific_results(root)
    expected=json.loads((root/'expected-scientific-results.json').read_text())
    if result!=expected:
        raise ValueError('Scientific subset differs from original retained result')
    return result


if __name__=='__main__':
    result=replay(HERE)
    print(json.dumps({'status':'matched exact scientific subset and six R control CSVs','rows':result['recording_structure']['rows'],'represented_unit_minutes':result['recording_structure']['recorded_provisional_unit_minutes'],'original_http_and_document_body_verification':False,'historical_dplyr_replay':False},indent=2))
