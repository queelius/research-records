"""Sampling identifiability diagnostics; synthetic joins are never NEON estimates."""
from collections import Counter, defaultdict
import csv
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
import math
from pathlib import Path
from typing import Sequence


class TargetStatus(StrEnum):
    PRESENT = 'Y'
    NOT_RECORDED = 'N'


@dataclass(frozen=True, order=True)
class ProvisionalUnit:
    site: str
    grid: str
    point: str
    observed: datetime


@dataclass(frozen=True)
class Observation:
    site: str
    grid: str
    point: str
    observed: datetime
    campaign: str
    minute: int
    value: float | None
    target: TargetStatus
    taxon: str | None

    @property
    def unit(self) -> ProvisionalUnit:
        return ProvisionalUnit(self.site, self.grid, self.point, self.observed)


def load_observations(path: Path) -> list[Observation]:
    """Read typed rows and reject malformed identifiers, intervals and statuses."""
    required = {'siteID', 'plotID', 'pointID', 'observation_datetime', 'unique_sample_id',
                'pointCountMinute', 'value', 'targetTaxaPresent', 'taxon_id'}
    result = []
    with path.open(newline='') as handle:
        reader = csv.DictReader(handle)
        if not required.issubset(reader.fieldnames or []):
            raise ValueError('Required snapshot columns absent')
        for row in reader:
            if None in row or any(not row[k] for k in required - {'value', 'taxon_id'}):
                raise ValueError('Missing key or malformed CSV row')
            observed = datetime.fromisoformat(row['observation_datetime'])
            minute = int(row['pointCountMinute'])
            value = float(row['value']) if row['value'] else None
            target = TargetStatus(row['targetTaxaPresent'])
            taxon = row['taxon_id'] or None
            if minute < 1:
                raise ValueError('Nonpositive minute code')
            if value is not None and (not math.isfinite(value) or value < 0):
                raise ValueError('Invalid cluster size')
            if (target == TargetStatus.PRESENT and (value is None or taxon is None)) or (
                target == TargetStatus.NOT_RECORDED and (value is not None or taxon is not None)
            ):
                raise ValueError('Inconsistent count/target evidence')
            result.append(Observation(row['siteID'], row['plotID'], row['pointID'], observed,
                                      row['unique_sample_id'], minute, value, target, taxon))
    return result


def effort_audit(rows: Sequence[Observation]) -> dict:
    """Minute records describe retained recording, not verified completion."""
    if not rows:
        raise ValueError('No observation evidence')
    strata = defaultdict(set)
    units = defaultdict(set)
    for row in rows:
        units[row.unit]  # Include units represented only by incidental codes.
        if row.minute in range(1, 7):
            strata[(row.unit, row.minute)].add(row.target)
            units[row.unit].add(row.minute)
    by_grid_rows = Counter((row.site, row.grid) for row in rows)
    by_grid_units = Counter((unit.site, unit.grid) for unit in units)
    coverage = Counter(len(minutes) for minutes in units.values())
    return {
        'rows':len(rows), 'provisional_units':len(units), 'grids':len(by_grid_rows),
        'campaigns':len({row.campaign for row in rows}),
        'coverage_histogram':{str(k):v for k,v in sorted(coverage.items())},
        'provisional_units_with_all_minutes_represented':coverage[6],
        'recorded_provisional_unit_minutes':len(strata),
        'missing_provisional_unit_minutes':6*len(units)-len(strata),
        'recorded_detection_only_unit_minutes':sum(v == {TargetStatus.PRESENT} for v in strata.values()),
        'recorded_no_target_only_unit_minutes':sum(v == {TargetStatus.NOT_RECORDED} for v in strata.values()),
        'mixed_target_status_unit_minutes':sum(len(v)>1 for v in strata.values()),
        'recorded_cluster_size_sum':sum(row.value or 0 for row in rows),
        'protocol_cluster_size_sum':sum(row.value or 0 for row in rows if row.minute in range(1, 7)),
        'outside_protocol_rows':sum(row.minute not in range(1, 7) for row in rows),
        'outside_protocol_codes':{str(k):v for k,v in sorted(Counter(row.minute for row in rows if row.minute not in range(1, 7)).items())},
        'independently_completed_units':None,
        'grid_row_sizes':sorted(by_grid_rows.values()),
        'grid_provisional_unit_sizes':sorted(by_grid_units.values()),
        'scope':'Derived HARV2020 recording structure only; no independently verified effort or source cardinality.'
    }


def design_effect(group_sizes: Sequence[int], rho: float) -> dict:
    """Variance ratio for equal-variance exchangeable observations within groups."""
    if not group_sizes or any(type(n) is not int or n < 1 for n in group_sizes):
        raise ValueError('Positive integer group sizes required')
    if not math.isfinite(rho) or not 0 <= rho <= 1:
        raise ValueError('Correlation outside [0,1]')
    n = sum(group_sizes)
    effect = 1 + rho * (sum(size**2 for size in group_sizes)/n - 1)
    return {'rho_assumed':rho, 'rows':n, 'groups':len(group_sizes),
            'design_effect':effect, 'effective_rows':n/effect,
            'interpretation':'Conditional equal-variance intragroup model; rho is not estimated.'}


@dataclass(frozen=True)
class PointSurvey:
    site: str
    grid: str
    point: str
    event: str
    start: str
    uid: str
    complete: bool


@dataclass(frozen=True)
class CountRecord:
    site: str
    grid: str
    point: str
    event: str
    start: str
    uid: str
    minute: int
    value: float


def audit_join(points: Sequence[PointSurvey], counts: Sequence[CountRecord], fields: tuple[str, ...]) -> dict:
    """Explicit downward equality join, with cardinality and a lossy projection.

    Shared source-key fields are structurally derived from both dataclasses;
    uid is record-specific and is never a cross-table join key.
    """
    shared = PointSurvey.__dataclass_fields__.keys() & CountRecord.__dataclass_fields__.keys() - {'uid'}
    if not fields or len(set(fields)) != len(fields) or not set(fields) <= shared:
        raise ValueError('Invalid cross-table key fields')
    def key(row):
        values = tuple(getattr(row, field) for field in fields)
        if any(value is None or value == '' for value in values):
            raise ValueError('Missing source key')
        return values
    lookup = defaultdict(list)
    for index, count in enumerate(counts):
        lookup[key(count)].append((index, count))
    multiplicities = [0] * len(counts)
    projection = set()
    joined = empty = 0
    for point in points:
        matches = lookup.get(key(point), [])
        if not matches:
            empty += 1
            joined += 1
            projection.add((point.site, point.grid, point.point, point.event, point.start, None, None))
        for index, count in matches:
            multiplicities[index] += 1
            joined += 1
            projection.add((point.site, point.grid, point.point, point.event, point.start, count.minute, count.value))
    return {'point_rows':len(points), 'count_rows':len(counts),
            'complete_points':sum(p.complete for p in points), 'joined_rows':joined,
            'matched_count_copies':sum(multiplicities),
            'unmatched_count_rows':sum(n == 0 for n in multiplicities),
            'max_count_multiplicity':max(multiplicities,default=0),
            'zero_count_point_rows':empty, 'projected_unique_rows':len(projection),
            'projection':sorted(projection,key=repr),
            'synthetic':True}
