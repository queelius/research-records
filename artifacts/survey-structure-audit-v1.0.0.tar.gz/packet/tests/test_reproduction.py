"""Portable tests: only this packet, Python standard library and base R."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

PACKET=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKET))
import reproduce

class PortableTests(unittest.TestCase):
    def test_exact_scientific_replay_without_modifying_packet(self):
        files=[p for p in PACKET.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
        before={str(p):sha256(p.read_bytes()).hexdigest() for p in files}
        result=reproduce.replay(PACKET)
        self.assertEqual(result['recording_structure']['protocol_cluster_size_sum'],1066)
        self.assertEqual(result['recording_structure']['outside_protocol_rows'],34)
        self.assertEqual(result['recording_structure']['mixed_target_status_unit_minutes'],1)
        self.assertEqual(before,{str(p):sha256(p.read_bytes()).hexdigest() for p in files})

    def test_mutations_of_data_code_and_expected_outputs_are_rejected(self):
        for relative in ['data/observations.csv','analysis.py','source_policy_controls.R','expected-scientific-results.json']:
            with self.subTest(relative=relative),tempfile.TemporaryDirectory() as temporary:
                root=Path(temporary)/'packet';shutil.copytree(PACKET,root)
                with (root/relative).open('ab') as handle:handle.write(b'corruption')
                with self.assertRaisesRegex(ValueError,'Pinned bytes changed'):
                    reproduce.replay(root)

    def test_missing_file_and_unsafe_pin_are_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary)/'packet';shutil.copytree(PACKET,root)
            (root/'data/observations.csv').unlink()
            with self.assertRaises(ValueError):reproduce.verify_pins(root)
            pins={'files':[{'path':'../outside','sha256':'x'}]}
            (root/'pins.json').write_text(json.dumps(pins))
            with self.assertRaisesRegex(ValueError,'Unsafe pin path'):reproduce.verify_pins(root)

    def test_scientific_mismatch_is_rejected_even_after_repinning_expected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary)/'packet';shutil.copytree(PACKET,root)
            expected=root/'expected-scientific-results.json'
            data=json.loads(expected.read_text());data['recording_structure']['rows']=0
            expected.write_text(json.dumps(data))
            pins=json.loads((root/'pins.json').read_text())
            for item in pins['files']:
                if item['path']=='expected-scientific-results.json':item['sha256']=sha256(expected.read_bytes()).hexdigest()
            (root/'pins.json').write_text(json.dumps(pins))
            with self.assertRaisesRegex(ValueError,'Scientific subset differs'):reproduce.replay(root)

if __name__=='__main__':unittest.main()
