# Offline reproducible audit packet

Read NOTE.md for the exact claim, attribution and limits. From any directory:

```sh
python3.12 -B /path/to/packet/reproduce.py
python3.12 -B -m unittest discover -s /path/to/packet/tests -v
```

Python 3.12 standard library and base R (tested R 4.3.3) suffice. No installation,
account or network is needed. Replay reads this packet, uses a temporary external
directory for R controls, checks pins and compares the exact scientific subset
and all six synthetic control CSVs. It never modifies retained evidence. It does
not reverify external HTTP responses or source-document bodies, and does not
execute the full historical dplyr pipeline.

provenance.json records the exact nine-column projection and original hashes.
expected-scientific-results.json is a named subset of the original scientific
output, not a relabeled full historical run. Source access and operational logs
are omitted. pins.json checks files within this archive; the externally supplied
archive SHA-256 authenticates the pin set itself. Software MIT, original note
CC BY4.0, predecessor inputs CC0; see LICENSE.md. No DOI or public release yet.
